# Shared transition development report

One manifold and one event table serve every method.
Region codes are geometric summaries; correspondence diversity and feature omission
scores are descriptive development evidence, without identified biological necessity.

| Method | Status | Held-out log-loss gain |
|---|---|---|
| conventional_cgc | available | -0.0893300492568685 |
| conventional_cgc_star | available | -0.06998831809137784 |
| fast_cgc | available | 0.011236397058459913 |
| fast_cgc_star | available | 0.030327580967663748 |

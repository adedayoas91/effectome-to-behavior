| Scenario | Method | Available seed pairs/planned | Mean gain (nats) | SD | Eligible directions | Status |
|---|---|---|---|---|---|---|
| single_driver | conventional_cgc | 20/20 | -0.010 | 0.019 | 40/40 | fail |
| redundant_group | conventional_cgc | 20/20 | -0.263 | 0.135 | 40/40 | fail |
| correlated_bystander | conventional_cgc | 20/20 | -0.014 | 0.020 | 40/40 | fail |
| null | conventional_cgc | 60/60 | -0.086 | 0.053 | 120/120 | fail |
| hidden_confounder | conventional_cgc | 20/20 | -0.006 | 0.006 | 40/40 | diagnostic |
| single_driver | conventional_cgc_star | 20/20 | -0.014 | 0.010 | 40/40 | fail |
| redundant_group | conventional_cgc_star | 20/20 | -0.191 | 0.094 | 40/40 | fail |
| correlated_bystander | conventional_cgc_star | 20/20 | -0.013 | 0.019 | 40/40 | fail |
| null | conventional_cgc_star | 60/60 | -0.070 | 0.050 | 120/120 | fail |
| hidden_confounder | conventional_cgc_star | 20/20 | -0.006 | 0.005 | 40/40 | diagnostic |
| single_driver | fast_cgc | 20/20 | -0.013 | 0.017 | 40/40 | fail |
| redundant_group | fast_cgc | 20/20 | -0.242 | 0.122 | 40/40 | fail |
| correlated_bystander | fast_cgc | 20/20 | -0.014 | 0.017 | 40/40 | fail |
| null | fast_cgc | 60/60 | -0.092 | 0.058 | 120/120 | fail |
| hidden_confounder | fast_cgc | 20/20 | -0.006 | 0.006 | 40/40 | diagnostic |
| single_driver | fast_cgc_star | 20/20 | -0.012 | 0.011 | 40/40 | fail |
| redundant_group | fast_cgc_star | 20/20 | -0.133 | 0.070 | 40/40 | fail |
| correlated_bystander | fast_cgc_star | 20/20 | -0.009 | 0.015 | 40/40 | fail |
| null | fast_cgc_star | 60/60 | -0.054 | 0.031 | 120/120 | fail |
| hidden_confounder | fast_cgc_star | 20/20 | -0.008 | 0.006 | 40/40 | diagnostic |

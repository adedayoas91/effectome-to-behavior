# Figure catalog

## figure-01-predictive-gain.pdf / .png

Purpose: assess whether graph augmentation predicts the same future outcomes better than M0. Points are mean seed-level nats gains; error bars are 95% seed-bootstrap intervals when available. For compactness the first declared specification per scenario is shown; full numeric tables cover every specification. Notice negative as well as positive gains and intervals spanning zero. This identifies follow-up comparisons, not neuronal necessity.

## figure-02-availability.pdf / .png

Purpose: expose numerical/eligibility failures rather than selecting successful methods. Bars show available/attempted method runs across all executed cells. These are exact counts, with no sampling error bars. Low availability limits scientific comparison; an unavailable method is not evidence of poor biological validity.

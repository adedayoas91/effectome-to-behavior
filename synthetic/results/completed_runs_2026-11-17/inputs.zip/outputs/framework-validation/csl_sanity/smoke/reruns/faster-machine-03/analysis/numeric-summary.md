| Scenario/spec | Method | Seeds available/planned | Mean gain (nats) | SD | 95% CI | Holm p |
|---|---|---|---|---|---|---|
| matched_marginals/354821 | conventional_cgc | 3/3 | -0.16529 | 0.1426 | [-0.2511, -0.0006826] | 1 |
| matched_marginals/354821 | conventional_cgc_star | 3/3 | -0.058948 | 0.039813 | [-0.1049, -0.03434] | 1 |
| matched_marginals/354821 | fast_cgc | 3/3 | -0.024108 | 0.038167 | [-0.05978, 0.01614] | 1 |
| matched_marginals/354821 | fast_cgc_star | 3/3 | -0.021977 | 0.019299 | [-0.03616, 2.22e-16] | 1 |
| stationary/c5d401 | conventional_cgc | 3/3 | -0.027961 | 0.042584 | [-0.07318, 0.01138] | 1 |
| stationary/c5d401 | conventional_cgc_star | 3/3 | 0.00075545 | 0.045046 | [-0.05122, 0.02839] | 1 |
| stationary/c5d401 | fast_cgc | 3/3 | 0.00693 | 0.012003 | [-4.441e-15, 0.02079] | 1 |
| stationary/c5d401 | fast_cgc_star | 3/3 | 5.6991e-15 | 1.18e-14 | [-4.441e-15, 1.865e-14] | 1 |
| fixed_circuit/e873df | conventional_cgc | 3/3 | -0.003189 | 0.002491 | [-0.004706, -0.0003141] | 1 |
| fixed_circuit/e873df | conventional_cgc_star | 3/3 | -0.00040552 | 0.00070238 | [-0.001217, 3.486e-14] | 1 |
| fixed_circuit/e873df | fast_cgc | 3/3 | -0.0018779 | 0.002454 | [-0.004706, -0.0003141] | 1 |
| fixed_circuit/e873df | fast_cgc_star | 3/3 | 1.8282e-14 | 1.612e-14 | [2.665e-15, 3.486e-14] | 1 |
| one_to_one/fe0d90 | conventional_cgc | 3/3 | -0.37217 | 0.40725 | [-0.7989, 0.01226] | 1 |
| one_to_one/fe0d90 | conventional_cgc_star | 3/3 | -0.038429 | 0.0891 | [-0.1376, 0.03487] | 1 |
| one_to_one/fe0d90 | fast_cgc | 3/3 | -0.073192 | 0.11762 | [-0.2089, 1.603e-13] | 1 |
| one_to_one/fe0d90 | fast_cgc_star | 3/3 | -0.0051824 | 0.0089761 | [-0.01555, 1.603e-13] | 1 |

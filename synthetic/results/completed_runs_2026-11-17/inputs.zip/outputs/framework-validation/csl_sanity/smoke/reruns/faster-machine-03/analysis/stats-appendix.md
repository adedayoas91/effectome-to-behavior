# Statistical specification

Independent unit: a newly simulated raw-process seed, paired across methods. Specifications remain separate; overlapping anchors and methods are never replicates.

Manifold and native state codes are fitted separately for each seed. Transition codes in the attribution export are local to that seed and must not be pooled by numeric label across seeds.

Report mean, sample SD, median, raw nats gain and positive-seed fraction. Percentile bootstrap 95% intervals resample independent seeds within a specification, with at least three available seeds and the complete planned seed set. Intervals at small n are exploratory and coverage is not established.

The exact two-sided sign test tests equal probability of positive and negative seed-level gain, excluding exact zero ties. It requires independent seeds; it does not assume Gaussian gains. No parametric test or normality-based test selection was used. Missing planned seeds suppress inference for that contrast. Holm correction uses the entire planned contrast family; unavailable contrasts enter as p=1. No best-seed selection or neuron-level significance is reported.

Graph recovery is scored only on unmixed generating histories and in common scaled units. Under calcium/noise observation changes, latent structural coefficients are not automatically the observed-process estimand. Those recovery entries remain unavailable.

# Shared-transition framework validation

This is a bounded development run. The declared manuscript matrix has not been completed.

Primary question: does each graph representation improve held-out transition log loss over the same activity/history baseline? Positive gain favors graph augmentation.

Attempted method runs: 48; available: 48. Planned contrasts: 16. All seeds, failures and unavailable contrasts are retained.

The numerical table is `numeric-summary.md`. Figures show the observed seed-level gains and method availability. Snapshot correspondence and graph-code diversity do not establish circuit equivalence. No real animals or physical interventions were evaluated.

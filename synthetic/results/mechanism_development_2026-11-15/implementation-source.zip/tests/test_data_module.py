"""Tests for schema, loaders, preprocessing, and windowing."""

from __future__ import annotations

import numpy as np
import pytest
from scipy import signal

from effectome.data_module import (
    ArtifactProvenance,
    CalciumSegmentationConfig,
    CommunitySeries,
    ConnectivitySeries,
    NeuralRecording,
    PreprocessConfig,
    RecordingIdentity,
    TemporalAnchor,
    WindowConfig,
    bundle_net_bandpass,
    exclude_named_neurons,
    get_loader,
    make_overlapping_calcium_windows,
    make_taper,
    make_windows,
    preprocess,
    segment_calcium_traces,
)
from effectome.manifold import ManifoldArtifact, TargetSlice


def test_synthetic_loader_shapes():
    rec = get_loader("synthetic")(
        {
            "name": "synthetic",
            "dataset_id": "synthetic-benchmark",
            "recording_id": "synthetic-recording-0",
            "n_neurons": 10,
            "n_timepoints": 500,
        }
    )
    assert rec.traces.shape == (10, 500)
    assert rec.time.shape == (500,)
    assert "true_graphs" in rec.metadata
    assert rec.identity.dataset_id == "synthetic-benchmark"
    assert rec.identity.recording_id == "synthetic-recording-0"


def test_preprocess_zscore(synthetic_recording):
    pre = preprocess(synthetic_recording, PreprocessConfig(detrend=True, zscore=True))
    # z-scored traces have ~unit variance per neuron.
    assert np.allclose(pre.traces.std(axis=1), 1.0, atol=0.2)
    # input is not mutated.
    assert pre.traces is not synthetic_recording.traces
    assert pre.identity == synthetic_recording.identity


def test_bundle_net_bandpass_matches_pinned_upstream_implementation(synthetic_recording):
    traces = synthetic_recording.traces[:3, :200].astype(np.float64)
    fps = synthetic_recording.fps
    nyquist = fps / 2.0
    sos = signal.butter(
        4,
        [1.0e-10 * nyquist, 0.05 * nyquist],
        "bandpass",
        fs=fps,
        output="sos",
    )
    expected = signal.sosfilt(sos, traces, axis=1)
    expected = np.flip(expected, axis=1)
    expected = signal.sosfilt(sos, expected, axis=1)
    expected = np.flip(expected, axis=1)

    actual = bundle_net_bandpass(traces, fps)

    assert np.allclose(actual, expected, rtol=1e-12, atol=1e-12)


def test_bundle_net_bandpass_is_marked_retrospective_only(synthetic_recording):
    filtered = preprocess(
        synthetic_recording,
        PreprocessConfig(bundle_net_bandpass=True),
    )

    assert filtered.metadata["preprocess_dependency"]["kind"] == "global_noncausal_iir"
    assert filtered.metadata["bundle_net_reference"]["source_file"] == "functions.py"


def test_named_neuron_exclusion_uses_exact_raw_names(synthetic_recording):
    synthetic_recording.metadata["raw_neuron_names"] = [
        f"raw-{idx}" for idx in range(synthetic_recording.n_neurons)
    ]
    synthetic_recording.metadata["canonical_neuron_names"] = [
        f"canonical-{idx}" for idx in range(synthetic_recording.n_neurons)
    ]

    selected = exclude_named_neurons(
        synthetic_recording,
        ["raw-1", "canonical-2", "absent"],
        name_source="raw",
    )

    assert selected.n_neurons == synthetic_recording.n_neurons - 1
    assert "raw-1" not in selected.metadata["raw_neuron_names"]
    assert selected.metadata["excluded_neuron_names"] == ["raw-1"]
    assert selected.metadata["requested_but_absent_excluded_neuron_names"] == [
        "canonical-2",
        "absent",
    ]


def test_named_neuron_exclusion_is_idempotent(synthetic_recording):
    synthetic_recording.metadata["raw_neuron_names"] = [
        f"raw-{idx}" for idx in range(synthetic_recording.n_neurons)
    ]
    requested = ["raw-1", "absent"]

    selected = exclude_named_neurons(synthetic_recording, requested, name_source="raw")
    repeated = exclude_named_neurons(selected, requested, name_source="raw")

    assert repeated is selected
    assert repeated.metadata["excluded_neuron_names"] == ["raw-1"]
    assert repeated.metadata["requested_but_absent_excluded_neuron_names"] == ["absent"]


def test_sliding_windows_shapes(synthetic_recording):
    w = make_windows(synthetic_recording, WindowConfig(length=100, stride=50, mode="sliding"))
    assert w.segments.shape[1] == 100
    assert w.segments.shape[2] == synthetic_recording.n_neurons
    assert w.n_windows == len(w.windows)
    assert len(w.anchors) == w.n_windows
    for name in synthetic_recording.behavior:
        assert w.behavior_per_window[name].shape[0] == w.n_windows


def test_per_window_neuronal_standardization_is_local_and_scale_safe():
    traces = np.array(
        [
            [1, 2, 3, 4, 100, 120, 140, 160],
            [7, 7, 7, 7, 3, 3, 3, 3],
        ],
        dtype=np.float32,
    )
    recording = NeuralRecording(
        traces=traces.copy(),
        time=np.arange(8, dtype=np.float64),
        coords=None,
        neuron_ids=np.arange(2),
        behavior={"continuous": np.arange(8, dtype=np.float32)},
        fps=1.0,
    )

    windows = make_windows(
        recording,
        WindowConfig(
            length=4,
            stride=4,
            mode="sliding",
            standardize_per_window=True,
        ),
    )

    assert np.allclose(windows.segments.mean(axis=1), 0.0, atol=1.0e-7)
    assert np.allclose(windows.segments[:, :, 0].std(axis=1), 1.0, atol=1.0e-7)
    assert np.allclose(windows.segments[:, :, 1], 0.0)
    assert np.array_equal(recording.traces, traces)
    assert windows.metadata["neural_standardization"]["enabled"] is True
    assert windows.metadata["neural_standardization"]["constant_window_neuron_count"] == 2


def test_behavior_aligned_windows(synthetic_recording):
    w = make_windows(
        synthetic_recording,
        WindowConfig(length=60, stride=10, mode="behavior", align_event="motif", min_event_gap=20),
    )
    assert w.n_windows > 0
    assert w.segments.shape[1] == 60


def test_temporal_reference_windows_match_goal_contract():
    rec = get_loader("synthetic")(
        {
            "name": "synthetic",
            "dataset_id": "synthetic-benchmark",
            "recording_id": "synthetic-3000",
            "n_neurons": 8,
            "n_timepoints": 3000,
            "seed": 1,
        }
    )
    windows = make_windows(
        rec,
        WindowConfig(mode="temporal", history_length=500, target_length=15, stride=15),
    )

    assert windows.n_windows == 167
    assert windows.windows[0].start == 0
    assert windows.windows[0].stop == 500
    assert windows.anchors[0].target_start == 485
    assert windows.anchors[0].target_stop == 500
    assert windows.anchors[0].anchor_sample == 499
    assert windows.windows[1].start == 15
    assert windows.windows[1].stop == 515
    assert windows.anchors[1].target_start == 500
    assert windows.anchors[1].target_stop == 515
    assert windows.anchors[1].anchor_sample == 514
    assert windows.metadata["reference_profile"] == {
        "mode": "explicit_samples",
        "parameter_modes": {
            "history": "explicit_samples",
            "target": "explicit_samples",
            "stride": "explicit_samples",
        },
        "requested": {
            "history_length": 500,
            "history_seconds": pytest.approx(500 / rec.fps),
            "target_length": 15,
            "target_seconds": pytest.approx(15 / rec.fps),
            "stride": 15,
            "stride_seconds": pytest.approx(15 / rec.fps),
        },
        "resolved": {
            "history_length": 500,
            "history_seconds": pytest.approx(500 / rec.fps),
            "target_length": 15,
            "target_seconds": pytest.approx(15 / rec.fps),
            "stride": 15,
            "stride_seconds": pytest.approx(15 / rec.fps),
        },
    }
    assert windows.metadata["reference_profile_mode"] == "explicit_samples_reference"
    assert windows.metadata["temporal_contract"]["mode"] == "explicit_samples"
    assert windows.provenance.metadata["temporal_contract"]["history"]["resolved_samples"] == 500
    assert windows.provenance.metadata["temporal_contract"]["target"]["resolved_samples"] == 15
    assert windows.provenance.metadata["temporal_contract"]["stride"]["resolved_samples"] == 15


def test_temporal_windows_resolve_duration_first_contract_and_record_rounding():
    t = 120
    recording = NeuralRecording(
        traces=np.arange(2 * t, dtype=np.float32).reshape(2, t),
        time=np.arange(t, dtype=np.float64) / 10.0,
        coords=None,
        neuron_ids=np.arange(2),
        behavior={"motif": np.zeros(t, dtype=np.int64)},
        fps=10.0,
        identity=RecordingIdentity(dataset="synthetic", dataset_id="duration-test", recording_id="rec-0"),
    )

    windows = make_windows(
        recording,
        WindowConfig(
            mode="temporal",
            history_seconds=2.55,
            target_seconds=0.45,
            stride_seconds=0.45,
        ),
    )

    contract = windows.metadata["temporal_contract"]
    assert contract["mode"] == "duration_first"
    assert contract["history"]["resolved_samples"] == 26
    assert contract["target"]["resolved_samples"] == 5
    assert contract["stride"]["resolved_samples"] == 5
    assert contract["history"]["rounding_policy"] == "nearest_half_up"
    assert np.isclose(contract["history"]["rounding_error_seconds"], 0.05)
    assert np.isclose(contract["target"]["rounding_error_seconds"], 0.05)
    assert windows.metadata["history_seconds"] == 2.6
    assert windows.metadata["target_seconds"] == 0.5
    assert windows.windows[0].stop - windows.windows[0].start == 26
    assert windows.anchors[0].target_length == 5
    assert windows.provenance.metadata["temporal_contract"]["stride"]["requested_seconds"] == 0.45


def test_temporal_windows_scale_shared_duration_profile_by_recording_fps():
    cfg = WindowConfig(
        mode="temporal",
        history_seconds=120.0,
        target_seconds=5.164169588779088,
        stride_seconds=5.164169588779088,
    )

    def _recording(*, fps: float, timepoints: int, recording_id: str) -> NeuralRecording:
        return NeuralRecording(
            traces=np.zeros((3, timepoints), dtype=np.float32),
            time=np.arange(timepoints, dtype=np.float64) / fps,
            coords=None,
            neuron_ids=np.arange(3),
            behavior={"motif": np.zeros(timepoints, dtype=np.int64)},
            fps=fps,
            identity=RecordingIdentity(
                dataset="synthetic",
                dataset_id="shared-duration-profile",
                recording_id=recording_id,
            ),
        )

    worm = make_windows(_recording(fps=2.9046, timepoints=1600, recording_id="worm"), cfg)
    fish = make_windows(_recording(fps=6.0268, timepoints=2000, recording_id="fish"), cfg)

    assert worm.metadata["history_length"] == 349
    assert worm.metadata["target_length"] == 15
    assert worm.metadata["stride"] == 15
    assert worm.windows[0].stop == 349
    assert worm.anchors[0].target_start == 334
    assert worm.anchors[0].target_stop == 349

    assert fish.metadata["history_length"] == 723
    assert fish.metadata["target_length"] == 31
    assert fish.metadata["stride"] == 31
    assert fish.windows[1].start == 31
    assert fish.windows[1].stop == 754
    assert fish.anchors[1].target_start == 723
    assert fish.anchors[1].target_stop == 754


def test_temporal_windows_respect_gap_boundaries():
    t = 120
    traces = np.arange(3 * t, dtype=np.float32).reshape(3, t)
    time = np.arange(t, dtype=np.float64) / 10.0
    recording = NeuralRecording(
        traces=traces,
        time=time,
        coords=None,
        neuron_ids=np.arange(3),
        behavior={"motif": np.zeros(t, dtype=np.int64)},
        fps=10.0,
        metadata={"gap_intervals": [(40, 60)]},
        identity=RecordingIdentity(dataset="synthetic", dataset_id="gap-test", recording_id="rec-0"),
    )
    windows = make_windows(
        recording,
        WindowConfig(mode="temporal", history_length=20, target_length=5, stride=5),
    )

    assert [(w.start, w.stop) for w in windows.windows] == [
        (0, 20),
        (5, 25),
        (10, 30),
        (15, 35),
        (20, 40),
        (60, 80),
        (65, 85),
        (70, 90),
        (75, 95),
        (80, 100),
        (85, 105),
        (90, 110),
        (95, 115),
        (100, 120),
    ]
    assert all(not (window.start < 60 and window.stop > 40) for window in windows.windows)
    assert [idx for idx, anchor in enumerate(windows.anchors) if anchor.gap_before] == [5]
    assert [idx for idx, anchor in enumerate(windows.anchors) if anchor.gap_after] == [4]


def test_temporal_windows_expose_sparse_bad_frame_boundaries_without_retiming():
    t = 80
    recording = NeuralRecording(
        traces=np.arange(2 * t, dtype=np.float32).reshape(2, t),
        time=np.arange(t, dtype=np.float64) / 10.0,
        coords=None,
        neuron_ids=np.arange(2),
        behavior={"motif": np.zeros(t, dtype=np.int64)},
        fps=10.0,
        metadata={"bad_frame_intervals": [(24, 25)]},
        identity=RecordingIdentity(dataset="synthetic", dataset_id="bad-frame-test", recording_id="rec-0"),
    )

    windows = make_windows(
        recording,
        WindowConfig(mode="temporal", history_length=20, target_length=5, stride=5),
    )

    assert windows.metadata["bad_frame_intervals"] == [(24, 25)]
    assert [idx for idx, anchor in enumerate(windows.anchors) if anchor.bad_frame_after] == [0]
    assert [idx for idx, anchor in enumerate(windows.anchors) if anchor.bad_frame_before] == [1]
    assert windows.windows[0].stop == 20
    assert windows.windows[1].start == 5


def test_artifact_schema_rejects_unknown_version():
    with pytest.raises(ValueError, match="unsupported artifact schema version"):
        ArtifactProvenance(schema_version="999")


def test_c_elegans_loader_contract(tmp_path):
    path = tmp_path / "elegans_fixture.npz"
    traces = np.arange(24, dtype=np.float32).reshape(4, 6)
    np.savez(
        path,
        traces=traces,
        time=np.arange(6, dtype=np.float64) / 2.0,
        neuron_ids=np.array([11, 12, 13, 14]),
        behavior_motif=np.array([0, 0, 1, 1, 0, 0], dtype=np.int64),
        behavior_continuous=np.linspace(0.0, 1.0, 6, dtype=np.float32),
    )

    rec = get_loader("c_elegans")(
        {
            "name": "c_elegans",
            "path": str(path),
            "dataset_id": "elegans-ds",
            "recording_id": "animal-1",
            "behavior_keys": {
                "motif": "behavior_motif",
                "continuous": "behavior_continuous",
            },
            "keys": {"traces": "traces", "time": "time", "neuron_ids": "neuron_ids"},
        }
    )

    assert rec.identity.dataset_id == "elegans-ds"
    assert rec.identity.recording_id == "animal-1"
    assert rec.neuron_ids.tolist() == [11, 12, 13, 14]
    assert rec.metadata["source"] == "c_elegans"
    assert rec.behavior["motif"].tolist() == [0, 0, 1, 1, 0, 0]


def test_overlapping_calcium_segmentation_preserves_context_and_centers():
    data = np.arange(100 * 3, dtype=np.float32).reshape(100, 3)
    behavior = {"motif": (np.arange(100) // 10).astype(np.int64)}
    cfg = CalciumSegmentationConfig(
        core_length=20,
        stride=5,
        left_context=4,
        right_context=6,
        lag_context=8,
        taper="none",
        apply_taper=False,
    )

    windows = segment_calcium_traces(data, cfg, behavior=behavior, fps=10.0)

    assert windows.segments.shape == (14, 34, 3)
    assert windows.windows[0].start == 0
    assert windows.windows[0].stop == 34
    assert windows.metadata["core_windows"][0].start == 8
    assert windows.metadata["core_windows"][0].stop == 28
    assert windows.metadata["center_samples"][0] == 17.5
    assert np.isclose(windows.metadata["center_times"][0], 1.75)
    assert np.isclose(windows.metadata["overlap_fraction"], 1.0 - 5 / 34)
    assert windows.behavior_per_window["motif"].shape == (windows.n_windows,)


def test_overlapping_calcium_segmentation_applies_taper():
    data = np.ones((40, 2), dtype=np.float32)
    cfg = CalciumSegmentationConfig(
        core_length=10,
        stride=2,
        left_context=3,
        right_context=3,
        taper="hann",
        apply_taper=True,
    )

    windows = segment_calcium_traces(data, cfg)
    weights = windows.metadata["sample_weights"]

    assert np.isclose(weights[0], 0.0)
    assert weights.max() > 0.9
    assert np.allclose(windows.segments[0, :, 0], weights)


def test_make_overlapping_calcium_windows_from_recording(synthetic_recording):
    cfg = CalciumSegmentationConfig(core_length=50, stride=10, left_context=8, right_context=8)
    windows = make_overlapping_calcium_windows(synthetic_recording, cfg)

    assert windows.segments.shape[1] == cfg.full_length
    assert windows.segments.shape[2] == synthetic_recording.n_neurons
    assert windows.metadata["segmentation"] == "overlapping_calcium"
    for name in synthetic_recording.behavior:
        assert windows.behavior_per_window[name].shape[0] == windows.n_windows


def test_taper_variants():
    assert np.allclose(make_taper(5, "none"), 1.0)
    assert make_taper(5, "gaussian").shape == (5,)


def test_schema_artifacts_carry_typed_provenance_and_alignment():
    provenance = ArtifactProvenance(
        identity=RecordingIdentity(dataset="synthetic", dataset_id="ds", recording_id="rec"),
        stage="stage-4",
        source="unit-test",
    )
    anchors = [
        TemporalAnchor(
            dataset_id="ds",
            recording_id="rec",
            animal_id=None,
            session_id=None,
            segment_id="seg-0",
            context_start=0,
            context_stop=20,
            target_start=15,
            target_stop=20,
            anchor_sample=19,
            anchor_time_seconds=1.9,
            sampling_rate_hz=10.0,
        ),
        TemporalAnchor(
            dataset_id="ds",
            recording_id="rec",
            animal_id=None,
            session_id=None,
            segment_id="seg-0",
            context_start=5,
            context_stop=25,
            target_start=20,
            target_stop=25,
            anchor_sample=24,
            anchor_time_seconds=2.4,
            sampling_rate_hz=10.0,
        ),
    ]
    series = ConnectivitySeries(
        matrices=np.zeros((2, 3, 3), dtype=np.float32),
        window_starts=np.array([0, 5], dtype=np.int64),
        method="manual",
        directed=True,
        anchors=anchors,
        provenance=provenance,
    )
    community = CommunitySeries(
        labels=np.array([[0, 0, 1], [0, 1, 1]], dtype=np.int64),
        method="temporal",
        n_communities_per_window=np.array([2, 2], dtype=np.int64),
        window_starts=np.array([0, 5], dtype=np.int64),
        anchors=anchors,
        signed=True,
        directed=True,
        resolution=1.0,
        interlayer_coupling=0.5,
        boundary_indices=np.array([0, 2], dtype=np.int64),
        provenance=provenance,
    )

    assert series.provenance.identity.recording_id == "rec"
    assert anchors[0].history_seconds == 2.0
    assert anchors[0].target_seconds == 0.5
    assert np.array_equal(community.consensus_labels, community.labels)
    assert community.boundary_indices.tolist() == [0, 2]


def test_schema_alignment_validation_rejects_mismatched_lengths():
    anchor = TemporalAnchor(
        dataset_id="ds",
        recording_id="rec",
        animal_id=None,
        session_id=None,
        segment_id=None,
        context_start=0,
        context_stop=20,
        target_start=15,
        target_stop=20,
        anchor_sample=19,
        anchor_time_seconds=1.9,
        sampling_rate_hz=10.0,
    )

    with pytest.raises(ValueError, match="window_starts must align"):
        ConnectivitySeries(
            matrices=np.zeros((1, 2, 2), dtype=np.float32),
            window_starts=np.array([3], dtype=np.int64),
            method="manual",
            directed=True,
            anchors=[anchor],
        )

    with pytest.raises(ValueError, match="target_slices length"):
        ManifoldArtifact(
            method="classical",
            behavior_key="motif",
            full_embedding=np.zeros((25, 2), dtype=np.float32),
            window_embedding=np.zeros((2, 2), dtype=np.float32),
            target_slices=[TargetSlice(15, 20)],
            target_length=5,
        )

    with pytest.raises(ValueError, match="target_slices must align"):
        ManifoldArtifact(
            method="classical",
            behavior_key="motif",
            full_embedding=np.zeros((25, 2), dtype=np.float32),
            window_embedding=np.zeros((1, 2), dtype=np.float32),
            target_slices=[TargetSlice(10, 15)],
            target_length=5,
            window_starts=np.array([0], dtype=np.int64),
            anchors=[anchor],
        )

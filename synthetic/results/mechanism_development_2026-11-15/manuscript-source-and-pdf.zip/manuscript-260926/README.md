# From Dynamic Effectomes to Behavior — causal framework revision

Method synchronization: 1 November 2026, against package `dev` revision `62b1a20`. Historical implementation snapshots below retain their original dates.

Notebook organization update: 11 November 2026. The 173 retained notebooks are
organized by numbered analysis stage, with estimator names in filenames rather
than estimator-specific subdirectories. No implemented estimator lane was
removed; PCMCI+/JPCMCI+ remain explicitly scoped CSL sensitivities rather than
replacements for the existing comparisons.

Current engineering verification covers all 392 collected tests, repository
lint, static typing over the source package, and parsing of all 543 notebook
code cells. This verifies software integrity, not the manuscript's causal or
biological claims.

This self-contained manuscript was copied from `../mdpi_entropy/` and revised against [the independent review](../report.md). The original manuscript is preserved. The accompanying development package provides a reference implementation of the core contracts and estimators specified here. This manuscript still reports no new biological results, completed publication-scale method comparison/calibration, or identified intervention effect. The bounded raw-process development check and notebook preflight are reported separately.

## Read and build

- [Compiled manuscript](main.pdf)
- [Main LaTeX source](main.tex)
- [Detailed methodology](sections/methodology.tex)
- [Validation and acceptance tests](sections/validation.tex)
- [Review-to-revision map and implementation handoff](REVISION_NOTES.md)
- [Citation provenance](citation_audit.md)
- [Editorial review and figure rationale](EDITORIAL_REVIEW.md)
- [Independent-review implementation and remaining scientific work](REVIEW_IMPLEMENTATION.md)
- [Revised workflow figure (PDF)](figures/effectome-workflow-revised.pdf) / [PNG](figures/effectome-workflow-revised.png)

From this directory, run `tectonic --keep-logs main.tex`.

The MDPI `Definitions/` bundle is copied unchanged. Figure 1 uses the editable vector source `figures/revised-workflow.tex` to show the baseline comparison, optional summaries, and simulation checks. Figure 2 explains forecast timing. The original PNG is retained as an unused source asset. To rebuild the standalone workflow export, run `tectonic effectome-workflow-revised.tex` from `figures/`; from the manuscript directory, run `pdftoppm -singlefile -scale-to 2200 -png figures/effectome-workflow-revised.pdf figures/effectome-workflow-revised` for the PNG.

## Scientific choices in this draft

The organizing framework is causal structure learning under explicit temporal,
conditioning, observation, Markov, and faithfulness assumptions. The executable
comparison retains every implemented lane: windowed fastC-GC/fastC-GC* support
selection with signed VAR readouts, partial correlation, regularized constant and
windowed VAR, one-sided time-varying sparse VAR, and switching dynamics. PCMCI+
is an independent CSL sensitivity and JPCMCI+ is reserved for explicitly scoped
pooled/context-aware analyses. dLDS is a close comparator. No winner is declared.
Discrete states and node groups are optional, with no-state/no-group alternatives.
Roles are distinguished from assortative communities, and feature sensitivity is
distinguished from intervention modeling.

The fast backend builds on [c-GC/c-GC*](https://arxiv.org/abs/2501.02672) and cites the [fastC-GC/fastC-GC* paper](https://arxiv.org/abs/2610.37883) for its standardized ridge-residual statistics and complete-shift FFT calculations. The two papers are cited separately for the methodological basis and the fast estimator. The selected support can change, so the new backend requires its own calibration; its unsigned dependence scores are not substituted for the signed VAR coefficients. The backend specification uses the published linear formulation with complete-shift evaluation, a screening ridge of `1e-6`, and production conditional threshold `beta=0.005`; legacy analytic and sampled-shift procedures remain explicit sensitivities. Package version `0.1.0` is pinned to immutable source archive commit `985de54bf3d2474a5e692ad1d236c74f8452e197` and requires Python 3.14. This is a source revision pin, not a tagged stable release. The package environment records installation and verification status.

Two further methodological references inform the protocol: [the BSS study](https://arxiv.org/abs/2608.00655) motivates preserving measured trace variables and matching preprocessing controls, while [conditioning-depth diagnostics](https://arxiv.org/abs/2606.01214) motivate comparing graph support across deeper histories at a fixed reported lag horizon. The latter was evaluated with c-GC/c-GC*; its application to the fast backend is specified as a separately calibrated extension.

The primary behavioral test compares a training-selected graph-augmented model with a strong activity/history baseline. Training owns preprocessing, scaling, feature vocabularies, state/group references, manifolds, and tuning. Animal generalization and online within-animal forecasting are separate evaluation scenarios.

All hyperparameter grids, simulation counts, and model choices are **proposed defaults**, not retrospective preregistration. Endpoint lineage, preparation-specific timing, a practical-effect threshold, and the confirmatory cohort must be finalized before confirmatory execution and evaluation. Fictive motor labels are not treated as independently observed movement.

## Review implementation — 31 October 2026

Community detection is retained as an optional structural analysis; neuronal roles and whole-graph states remain separate targets. The default role features now contain one signed incoming/outgoing profile per lag rather than duplicated signed, positive/negative, strength, and balance features. Legacy expanded features are explicitly named. Installed Leiden remains a separate structural comparator.

The state-analysis implementation compares a K-means baseline with a regularized diagonal Gaussian mixture, with a one-state alternative and training-fitted scaling/PCA. Frozen mixture probabilities quantify assignment uncertainty conditional on estimated graphs; they do not replace graph-uncertainty propagation. Effective representations, algorithms, and distances are recorded separately. The legacy RBF feature map is not presented as a causal-clustering kernel.

The default state workflow now selects predictive summaries on nested chronological splits purged by raw graph-history support. Targets use wholly future graph histories. State codes compete with constant and continuous ridge prediction; outer testing scores the frozen selected procedure. Frozen transition parameters are fitted on training codes and scored on untouched codes, without promoting label-shuffle significance into evidence of neural regimes. These are development tests of predictive compression; upstream preprocessing/graph ownership and raw-null calibration still require verification.

A scriptable seven-scenario raw-data state-calibration suite and history/dwell grid are available in the package, with separate smoke and development profiles. Its finite design diagnostics do not establish biological state recovery or population false-positive control. The primary M0/M1 comparison remains free of mandatory states/groups. A separately declared endpoint-driven graph-selection sensitivity complements the default neural-dynamics objective.

See [REVIEW_IMPLEMENTATION.md](REVIEW_IMPLEMENTATION.md) for the implementation map, commands, and remaining data/calibration requirements. The Markham dependence-contribution kernel and treatment-response causal K-means remain research comparators awaiting their own estimands, assumptions, and validation.

## Executable reference profile

The manuscript now specifies the exact 25% outer/inner chronological state splits, minimum four purged training pairs, training-owned graph coordinates, strict 1% inner compression margin, and separate held-out validation. Nonconverged mixtures are rejected. PCA components are capped by sample/feature dimensions; numerical rank is not estimated. Role features preserve common neuron axes by zeroing self-coefficients rather than deleting their slots.

All manifold notebooks default to three-component, five-fold cross-fitted PCA. Faithful BunDLe remains an explicitly optional retrospective reference on its own preprocessing. Current V2a recordings cannot support the prospective state split at the default history: unavailable results and reasons propagate through linking. The primary endpoint comparison does not require states or groups.

The current endpoint evaluator tunes per-history sparse VAR, not the entire candidate model set. Its M0 uses last activity, history means and standard deviations; the stronger activity/behavior/input-history baseline in the protocol remains to be implemented for the full benchmark. Endpoint-directed sparse-VAR tuning is reported separately from the default neural-dynamics objective.

Completed engineering evidence at `62b1a20`: all 173 notebook bootstrap/configuration cells execute, all 543 code cells parse, 378 tests pass with one optional PyTorch skip, repository lint passes, and mypy checks 77 files. Full biological notebook experiments were not rerun. The seven-draw raw smoke check selected multiple codes in three of four no-discrete-regime scenarios; two also exceeded the held-out compression margin. These are design diagnostics, not validated regime discoveries or population error rates. The 189-evaluation development grid and publication-scale protocol remain separate from that completed check.

See the package [readiness report](../effectome-to-behavior/NOTEBOOK_READINESS.md) and [experiment order](../effectome-to-behavior/exec_order.md).

## Implementation snapshot — 10 October 2026

The branch history through `da38c2c` contains the WP0--WP11 development series. WP0--WP8 supply the principal data, timing, predictive-model, evaluator, state, and transition contracts. WP9--WP11 add validation/reporting components, feature-sensitivity claim boundaries, configuration profiles, cache provenance, resumable execution, and notebook handoff support. At that date, end-to-end benchmarking and strict fitting requirements remained open; the 30 October update in REVISION_NOTES.md records subsequent implementation work. Scientific validation remains a separate requirement.

Engineering verification recorded on 10 October was 222 passing tests with 1 optional-backend skip, clean Ruff checks over source, pipeline, tests, and notebook helper code, and a clean mypy run over 62 source files. No notebook cells, biological analyses, 800/920-recording benchmark, or 600-recording independent calibration suite were executed for this status update.

## Verification and limits

The integrated draft compiles; its 34 citation keys and cross-references resolve, with no cited placeholders or duplicate labels. A source snapshot is retained before the method-synchronization edits. Minor underfull text-box warnings and an inherited `lineno` package encoding warning remain; these are not missing-content or undefined-reference errors.

The manuscript revision itself did not change datasets or existing experimental output. Compilation and engineering checks establish document and software integrity, not scientific validity. The proposed scientific claims still require publication-scale benchmarking and calibration, biological evaluation, and independent-population evidence.

The local preprint style suppresses the MDPI version/submission notices and empty editorial-date fields; the bundled class files remain unchanged.

# Review response, implementation handoff, and status

Date: 2026-09-26. Source review: [report.md](../report.md).

This document began as a manuscript revision rather than a code release. The table below preserves the 26 September review-to-revision handoff; the implementation update that follows records later engineering progress without implying that the proposed choices have been scientifically validated.

## Simulation-only validation revision — 15 November 2026

The current manuscript reports only conventional c-GC/c-GC* and fastC-GC/fastC-GC*
simulation results. Removed the superseded VAR-estimator comparison figures,
tables, driver-pilot results and signed-readout state-calibration outcome claims.
Generating-process controls and native four-CSL graph-sanity evidence remain.
VAR backends and real-data notebooks are preserved. The scheduled-origin driver
study uses fresh seeds and unchanged recovery gates; its generated result section
records actual completion and acceptance, including failures and incomplete runs.

## Causal framing and notebook organization — 11 November 2026

The manuscript is now organized around causal structure learning from dynamic
effectomes to behavioral prediction. The causal interpretation is conditional
on explicit temporal, observation, conditioning, Markov, faithfulness, and
sufficiency assumptions; graph-augmented forecasts are not described as
identified interventions.

All previously implemented estimator lanes remain available. The 173 retained notebooks
are flattened into numbered stage directories, with method names carried by
notebook filenames instead of method-specific subdirectories. PCMCI+/JPCMCI+
remain sensitivity analyses with their stated scope and do not replace the
retained c-GC, c-GC*, partial-correlation, sparse-VAR, windowed-VAR,
time-varying-VAR, or switching-VAR workflows.

The reorganized tree passes all 392 collected tests, repository lint, static
typing over the source package, and parsing of all 543 notebook code cells.

## Method synchronization — 1 November 2026

Aligned the manuscript with package `dev` commit `62b1a20`, replacing the obsolete branch reference. The methods now give the implemented state split fractions, full-history future response, training-coordinate ownership, strict compression margin and separate outer validation, frozen transition sample sets, shared role coordinates and one-role default. The primary comparison requires no states or groups; installed Leiden remains available.

All manifold notebook defaults are cross-fitted PCA, with faithful BunDLe kept as a separate optional retrospective reference. The supplied V2a state splits are unavailable at the default history and preserve their reasons rather than weakening purging. The endpoint-directed reference sensitivity currently tunes sparse VAR only; the compact implemented M0 and the stronger proposed baseline are distinguished explicitly.

The previous signed-readout development diagnostic results were removed from the
current manuscript on 15 November 2026. Notebook preflight and proposed
publication-scale validation remain separate from scientific recovery evidence.

## Independent-review implementation — 31 October 2026

Community detection remains optional structural analysis. It is not removed or conflated with temporal role inference. The implementation now uses one signed incoming/outgoing role representation per lag by default, with the expanded legacy representation explicitly identified.

The signed-lag state backend now includes regularized diagonal Gaussian mixtures alongside K-means and a one-state alternative. Training-fitted scaling/PCA, frozen held-out assignments, effective algorithm/distance metadata, and explicit descriptive-versus-prospective scope address the review's geometry and provenance findings. Mixture responsibilities remain conditional on estimated graphs. The legacy RBF map has no causal-kernel claim; its unvalidated spectral assignment is excluded from prospective state fitting.

The new nested state evaluator compares future-graph prediction from state codes against constant and continuous ridge baselines using purged inner/outer raw-history splits. Default state notebook/CLI entry points use this evaluator. Frozen training transition models are scored on untouched codes; label permutations are retained only as explicitly descriptive sequence diagnostics. A separate finite raw-data calibration implementation spans seven scenarios and history/dwell ratios; smoke execution is engineering evidence only. A declared endpoint-prediction graph-selection sensitivity now complements the default neural-dynamics selection objective, without outer-test tuning.

The methods and limitations sections were updated to match these implemented procedures. [REVIEW_IMPLEMENTATION.md](REVIEW_IMPLEMENTATION.md) maps changes to the review and distinguishes implemented checks from publication-scale calibration, independent endpoints/animals, and deferred causal-clustering research. No new biological result or validated-regime claim is introduced.

## fastC-GC backend revision — 31 October 2026

The windowed support-selection specification now uses fastC-GC/fastC-GC*'s linear profile with complete circular-shift enumeration, full pair evaluation, correlation-scale ridge `1e-6`, and production conditional threshold `beta=0.005`. The signed VAR readout still retains all target self-history. The original c-GC/c-GC* paper remains cited for the decision rule and conditioning sets; the new fastC-GC paper is cited for the standardized ridge-residual formulation and FFT/shared-precision calculations. These choices define different estimators and require renewed calibration rather than reuse of earlier results.

The code dependency is specified as package `fastcgc` version `0.1.0` from immutable source archive commit `985de54bf3d2474a5e692ad1d236c74f8452e197`, with Python 3.14. No PyPI distribution, version tags, or GitHub releases were available when this revision was prepared; the commit pin is not described as a stable release. Existing `cgc` and `cgc_star` configuration names remain compatible entry points, while runtime provenance distinguishes the fast backend and its version. Earlier analytic and sampled circular-shift modes remain explicit sensitivities.

The expanded conditioning set includes present-time rows within each historical estimation window. Only positive-lag cross-neuron edges are exported, and prospective forecasts retain the existing lagged-predictor model. Threshold attainability is checked against the complete-shift resolution; short histories can be ineligible. The package's verification record covers installation and code tests separately from the manuscript's proposed empirical validation.

## Trace-preservation and conditioning-depth citations — 31 October 2026

Added the BSS calcium-transient study to related work and preprocessing sensitivities, with measured-variable preservation and matched PCA, low-pass, and removal controls. Added conditioning-depth diagnostics to related work and temporal specification: compare deeper conditioning histories while holding reported lags and response times fixed. The published depth study evaluates c-GC/c-GC*; use with fastC-GC/fastC-GC* is a separately calibrated extension. Both references support specific protocol choices and are not presented as completed validation of this pipeline.

## Implementation update — 30 October 2026

The three end-to-end implementation gaps recorded in the 10 October update have been
addressed in the nested package's working tree:

- Confirmatory evaluation now supports one frozen development fit and independent evaluation
  animals. It requires explicit canonical neuron-panel mappings, verified external file hashes,
  registered endpoint/calibration/resource declarations and attainable null resolution. Exact
  or seeded plus-one Monte Carlo animal sign flips test paired predictive-loss symmetry;
  complete BY families retain unavailable members. These tests do not establish conditional
  graph information or dynamic structure. Whole-cohort checkpoints preserve budget failures.
- The packaged raw-process benchmark executes the primary M0/M1 workflow and five predictive
  comparators, with paired forecast/recovery scorecards, known-DGP raw-pipeline null draws,
  explicit unavailable metrics and resumable failure-aware reports. Native worm-0 timing and
  the 109-neuron stress/nonlinear/calibration baseline are explicit. Appendix C and the machine
  manifest retain correlated innovations as the ninth stress condition; the manuscript's
  variance-only stress wording differs. Variance-only fixed interactions are evaluated in the
  separate calibration suite. The selected scenario list and hashes are saved with each run.
- Attribution notebooks and Stage 6/7 now construct genuinely training-owned feature bundles
  with purged chronological histories, frozen scale/PCA/role parameters and training-only
  candidate/control selection. No candidate passing screening yields an unavailable result.
- Raw-data development manifests, preflight checks and fold-resumable primary CLI execution
  are documented in [ANALYSIS_RUNS.md](../effectome-to-behavior/ANALYSIS_RUNS.md).

Readiness here means executable development and benchmark workflows. Publication-scale
calibration, independent-animal biological evaluation, verified biological endpoints and
frozen practical-effect/calibration thresholds remain scientific acceptance requirements.
The optional generative intervention model remains outside the implemented scope.

Verification on the final working tree: 295 tests passed and one skipped; Ruff passed over
source, pipeline, tests and notebook helpers; mypy passed over 64 source/entrypoint files.
All 21 attribution notebooks' Python cells compile. Raw benchmark/resume, primary CLI/resume,
synthetic whole-cohort exact-null inference and a 19-draw development conditional-null
calibration smoke executed successfully. Preflight found five usable folds for worm 0 and
each of the two configured zebrafish recordings. No full biological evaluation or
publication-scale grid was executed.

## Implementation status update — 10 October 2026

The `astra-revise` branch now contains the development series through `da38c2c`:

- WP0--WP8 implement the principal artifact-lineage, future-target, training-owned preprocessing, predictive connectivity, outer-evaluation, prospective-state, sparse-VAR, TVVAR, switching-VAR, and transition contracts.
- WP9 (`2d52d07`) implements certified synthetic-generator primitives, the finite benchmark manifest, deterministic streams, resumable attempt records, and registered statistical helpers. It does not yet provide the complete packaged raw-recording benchmark/reporting workflow, and no publication-scale calibration grid has been run.
- WP10 (`1c701dc`) enforces feature-sensitivity language, unavailable-result semantics, finite-control resolution, and removal of biological-intervention promotion. Production pipeline/notebook entry points still need strict outer-owned fitting and frozen candidate/control-family gates. The optional generative intervention model remains deliberately unimplemented.
- WP11 (`da38c2c`) adds named development/legacy profiles, stricter confirmation checks, semantic cache provenance, resumable fold execution, progress reporting, and expanded method-lane notebooks. The notebook cells and biological workloads have not been executed.

Verification on the current branch produced 222 passing tests and 1 optional-backend skip, clean Ruff checks over source, pipeline, tests, and notebook helper code, and a clean mypy run over 62 source files. This is engineering evidence only. It does not replace the registered raw-process benchmark, independent calibration, biological reruns, or confirmatory population evidence.

## Findings mapped to revised specifications

| Review | Change in this manuscript | Validation/evidence requirement recorded in the original handoff |
|---|---|---|
| F1: overlapping-window contradiction | Window-weighted population projection, separate latent law and estimate; optional approximate local variation | Estimand and weighting metadata; simulation bias/latency analysis |
| F2: omitted self-history | Explicit support-restricted regression retains every target self-lag; only exported graph has zero diagonal | Repair signed refit; conditional-coefficient regression test |
| F3: future-dependent consensus | Training-only reference selection; prefix-causal assignments and coassignment ensemble | Default five-run future-perturbation tests |
| F4: incomplete nested fitting | Outer ownership, inner refitting, chronological replay, learned-target nesting, and separate online/purged protocols | Fold-local orchestration; dependency manifests; held-out perturbation tests |
| F5: endpoint provenance | Observed behavior and fictive annotations are distinct; label-neuron exclusion sensitivity | Verify pinned local file lineage, annotation future support, and reuse permissions |
| F6: overlap-induced persistence | Full raw-pipeline stationary nulls and detection-delay tests | Run independent null calibration across timing/measurement settings |
| F7: forced discrete/Markov states | C=1, smooth drift, nonrecurring changes, recurrent models; dwell/lumpability/CK checks | Compare on common neural outcomes; sufficient recurrence and uncertainty |
| F8: roles called communities | Separate role objective, assortative-community hypothesis, and optional general block likelihood | Validate grouping target; demonstrate predictive/compression or structural value |
| F9: inconsistent spectral assignment | Coherent inductive K-means baseline; training-only signed centroids; spectral extension only if verified | Fit/transform invariance and held-out-centroid independence |
| F10: inference/measurement gaps | Calibrated screening, marginal-detectability caveat, fixed scaling, sparse VAR comparator | False-discovery/sign/coverage tests at realistic dimensions and kinetics |
| F11: weak pilot/generalization | Strong activity/history baseline; paired animal log-loss gain; capacity matching and small-cohort limits | Independent animals and locked evaluation; no pilot result promoted to confirmation |
| F12: feature edits versus interventions | Separate algebraic feature sensitivity from a generative activity-level intervention operator | Predictive, rollout, and independent simulator intervention gates |
| F13: synthetic-design errors | Common companion-matrix contraction, latent versus observed projection truth, valid conditional-prediction null | Implement stable generators and Monte Carlo truth; run staged suite |
| F14: novelty/comparators | dLDS, sparse VAR, structural breaks, and switching dynamics incorporated | Fair comparative evaluation; novelty remains unestablished |
| F15: missing propagated uncertainty | Raw-data resampling refits upstream stages; optimizer uncertainty separated | Validate dependence assumptions and interval coverage |
| F16: formal details | Smoothed-chain interpretation, censored HSMM likelihood, sign contrasts, graph geometry, notation | Unit tests for units/orientation/censoring and output claim boundaries |

## Method hierarchy for the next phase

1. Repair temporal and statistical contracts before adding model complexity. Preserve self-history, training-only representations, causal consensus, and strictly future targets.
2. Implement the constant/windowed sparse VAR baseline and common one-step neural forecast interface. Graph-family selection uses standardized neural MSE; behavioral decoder selection uses inner log loss.
3. Add one-sided time-varying VAR, smooth and fused variants. Store issued endpoint coefficients separately from retrospective coefficient paths.
4. Add switching VAR with C=1 included and filtering-only prospective features. Keep change-point inference distinct from recurring states; evaluate dLDS only through an audited information-availability path.
5. Add graph-state quantization and role summaries only after the core models are calibrated. Dynamic signed block models and latent switching extensions are optional later work.
6. Run the raw-process null/recovery suite, then independent-animal prediction. Do not implement a biological intervention claim by renaming decoder feature sensitivity.

This ordering is a handoff proposal, not authorization to change the code in this manuscript-only revision.

## Suggested artifact contract

- `Recording`: native clock, masks, unique animal/ROI IDs, optional uncertain biological names, observation/annotation provenance.
- `SplitManifest`: outer/inner membership, calibration prefixes, raw dependency sets, allowed update policies, endpoint support.
- `PredictiveModel`: full lag coefficients including self-history, intercept/input terms, observation/noise model, fit indices, scales, penalties, solver status.
- `EffectomeSeries`: off-diagonal lag tensors, optional declared collapse, raw-unit readout, origin/dependency metadata, uncertainty provenance.
- `StateModel`: training transform and vocabulary, inductive assignment rule, filtered versus smoothed status, training-only signed centroids.
- `RoleModel`: training reference and scales, fixed versus causal updates, multirun coassignment and future-invariance status.
- `PredictionRecord`: issue time, feature/model hashes, target interval, probabilities or continuous prediction, unavailable-output reason.
- `ValidationReport`: independent units, paired risks, family definition, null provenance, calibration, failures, and claim gates.

These are semantic requirements; reuse existing project artifacts and interfaces where possible rather than introducing parallel abstractions automatically.

## Decisions deliberately left open

- Exact local label lineage and whether supplied signal corrections are prospectively available.
- Preparation-specific future target/horizon, registered neural panel, and handling of unavailable channels.
- A scientifically meaningful practical-effect threshold and adequate independent confirmatory cohort.
- Final resource ceilings and a frozen tuning plan after development-only feasibility checks.
- Whether optional states, roles, communities, latent dynamics, or interventions earn inclusion after calibration.

The manuscript provides concrete draft defaults where possible but does not fabricate answers to these empirical questions.

## Verification record — original revision (26 September 2026)

The unmodified copied template compiled before revision. The integrated revision compiles with Tectonic/BibTeX; all 31 cited keys resolve, and no duplicate labels, undefined references, or cited placeholders were found. Eight new reference records have retrieval provenance in `citation_audit.md`. The original `mdpi_entropy/` manuscript sources and bibliography remain unchanged, and old outputs were not edited. Minor typography/package warnings are documented in the README.

At the original revision, the manuscript was **not ready for submission as a validated methods/results paper**. The remaining work included WP9--WP11 end-to-end implementation, calibrated comparison, and independent endpoint/population evidence. The dated updates above record subsequent engineering progress. The revised document is a detailed working methods protocol with a tested development implementation, not a results report.

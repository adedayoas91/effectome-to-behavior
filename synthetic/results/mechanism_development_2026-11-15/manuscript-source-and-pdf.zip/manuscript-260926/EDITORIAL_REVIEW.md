# Editorial review — 31 October 2026

This editorial record precedes the subsequent fastC-GC backend revision; see [REVISION_NOTES.md](REVISION_NOTES.md#fastc-gc-backend-revision--31-october-2026) for that change. Counts below refer to the editorial pass.

The abstract, all six manuscript sections, author declarations, both figure sources, and supporting status documentation were reviewed for repetitive, formulaic, and unnecessarily defensive writing. These are editorial findings, not a determination of AI authorship.

## Findings and changes

| Finding | Revision applied |
| --- | --- |
| Repeated declarations that the manuscript is a protocol rather than a results paper | State the incomplete empirical status in the abstract and validation opening; shorten repeated declarations in the introduction, methods, conclusion, and author contribution statement. |
| Rebuttal language addressing hypothetical objections | Replace phrases about forcing dynamic states, manufacturing persistence, and a visually attractive segmentation with the model, assumption, or test involved. |
| Repeated novelty disclaimers | Describe dLDS and the other comparators directly, retaining their citations and the requirement for fair comparison. Remove repeated assertions that novelty remains unestablished. |
| Software-management wording inside scientific prose | Replace “split ownership,” “prospective lane,” and “failed gate” with training-only fitting, prospective prediction, and explicit acceptance criteria. Retain precise technical requirements where needed. |
| Long conclusion repeating the introduction and limitations | Reduce to the question, comparison, evaluation design, and evidence still needed. |
| Repeated negation and contrast | Use direct descriptions of predictive estimands, restricted projections, temporal dependence, and model selection. Keep negation where it prevents a specific interpretation error. |
| Mechanistic language for predictive coefficients | Use positive/negative coefficient patterns in place of suppression/facilitation in the block-model description. |
| Outdated status presented as current | Date the README's 10 October snapshot, link to the 30 October update, and label the original revision verification record as historical. No new software test results were asserted. |

Examples:

- “The protocol tests whether dynamic connectivity is needed, not how to force every recording into dynamic states” becomes “We compare constant, trailing-window, continuously varying, and switching models to test whether dynamic connectivity improves prediction.”
- “Temporal regularization explicitly manufactures some persistence” becomes “Temporal regularization increases persistence by construction.”
- “A failed gate yields an explicit unavailable result, not zero biological effect” becomes “If these requirements are unmet, report the model-based effect as unavailable.”

Necessary qualifications remain: predictive coefficients do not identify synaptic mechanisms or intervention effects; fictive annotations require a provenance audit; overlap limits temporal resolution; animals are the biological replication units; and optional states/groups require evidence. These statements have distinct methodological consequences and were not removed simply because they express uncertainty.

## Workflow figure decision

Keep a workflow figure. The manuscript compares several model families and separates the primary prediction test from optional graph summaries; a visual overview helps readers follow those branches.

The supplied PNG is unsuitable as the current scientific workflow:

- It makes c-GC/c-GC* the sole estimation route, although the protocol compares several families.
- It presents state clustering and communities as mandatory stages.
- It links inferred states to a behavior manifold without showing training-only fitting or prospective evaluation.
- Its facilitation/suppression ranking implies an interpretation beyond signed predictive coefficients or decoder feature sensitivity; the direction of its signed axis also needs an explicit definition before such a panel could be used.
- It omits the strong activity/history baseline, raw-recording nulls, and animal-level evaluation.

The manuscript already excluded this PNG and used a simple vector replacement. Figure 1 has now been redesigned in that existing TikZ source. It shows training-data model selection, graph features, the primary M0/M1 comparison, optional state/role/community summaries, and raw-recording simulations. It avoids invented neural traces, behavioral trajectories, rankings, and other panels that could be read as results. The original PNG remains as an archival asset.

The revised figure is called out in the methods and embedded as vector graphics in `main.pdf` (Figure 1, page 5). Separate PDF and PNG exports are in `figures/effectome-workflow-revised.*`. The `.tex` export wrapper reuses `revised-workflow.tex`, so the diagram has one editable source. Figure 2 retains its timing content with a shorter caption and clearer dependency wording.

## Verification

- Tectonic/BibTeX compilation of `main.tex` succeeds.
- All existing equation blocks, display mathematics, inline mathematics, citation commands, and labels in `main.tex` and the six sections are preserved, comparing mathematics after whitespace normalization.
- All 31 unique citation keys exist in `references.bib`; all 48 labels are unique and every reference has a matching label.
- No undefined references/citations, duplicate-label warnings, or overfull boxes occur in the final manuscript log.
- The rendered workflow and timing pages were inspected for readability, arrow paths, text overlap, and clipping. Standalone workflow export also compiles.
- Existing underfull paragraph warnings and the inherited `lineno` encoding warning remain.
- This pass checked citation preservation and resolution, not the accuracy of every cited source against its original publication. No empirical analyses or software test suite were rerun for this editorial revision.

Reproducible size comparison: whitespace-delimited LaTeX source tokens in `main.tex` plus `sections/*.tex` fell from **12,355 to 11,502** (853 fewer; **6.9%**). This includes commands and mathematics and is not a prose-only word count. Figure sources and documentation are excluded.

## Changed files and remaining limits

Edited `main.tex`, all six `sections/*.tex`, `figures/revised-workflow.tex`, `figures/timing-contract.tex`, `README.md`, and the historical status wording in `REVISION_NOTES.md`. Added this review, the standalone figure wrapper, and the figure PDF/PNG exports. Rebuilt `main.pdf` and its logs.

The manuscript remains a proposed evaluation protocol with a development implementation. Publication-scale calibration, independent-animal comparison, verified endpoint lineage, and a justified practical-effect threshold remain scientific requirements. The funding declaration still says that information was not provided; this review does not supply missing author metadata. Template files, the bibliography, and experimental outputs were not edited.

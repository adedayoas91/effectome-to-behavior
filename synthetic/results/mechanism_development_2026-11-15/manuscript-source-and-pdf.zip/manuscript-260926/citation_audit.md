# Citation audit — revision of 2026-09-26

## Scope and status

The bibliography in this directory was copied from mdpi_entropy/references.bib.
That source and its historical audit remain unchanged. This revision adds eight
records fetched from DOI content negotiation or publisher BibTeX exports, removes
the in-preparation rising-flanks placeholder, and refreshes the revision month
on the cited c-GC preprint. It does not constitute a fresh verification of every
unused inherited bibliography entry.

Metadata verification and claim verification are separate. New citations support
the limited methodological descriptions listed below, not the correctness of
the proposed pipeline or an empirical advantage that has not been demonstrated.
New entry keys were renamed consistently; LaTeX capitalization was protected and
page/article numbers were supplemented only from the linked primary records.

## New records and retrieval provenance

All retrievals below were made on 2026-09-26.

| Key | Trusted BibTeX export | Independent primary record / claim check |
|---|---|---|
| yezerets2025dlds | DOI content negotiation for [10.1038/s42003-025-08599-3](https://doi.org/10.1038/s42003-025-08599-3), requesting application/x-bibtex | [Publisher article](https://www.nature.com/articles/s42003-025-08599-3): title, authors, 2025, volume 8, article 1218. Model architecture, equations (1)–(3), and data description checked: dLDS combines operators; application uses Kato recordings with fictive annotations. |
| mudrik2024dlds | [JMLR BibTeX](https://www.jmlr.org/papers/v25/23-0777.bib) | [JMLR abstract and metadata](https://www.jmlr.org/papers/v25/23-0777.html) and [arXiv record](https://arxiv.org/abs/2206.02972): sparse combinations of dynamical components, overlapping processes, continuous changes. Published JMLR record is cited rather than the earlier preprint. |
| nicholson2020var | [JMLR BibTeX](https://www.jmlr.org/papers/v21/19-777.bib) | [JMLR article](https://www.jmlr.org/papers/v21/19-777.html) and [arXiv record](https://arxiv.org/abs/1412.5250): hierarchical lag structures and nested group regularization. This is a structured sparse VAR precedent, not a citation for the proposed online time-varying estimator. |
| safikhani2017breaks | DOI content negotiation for [10.48550/arXiv.1708.02736](https://doi.org/10.48550/arXiv.1708.02736) | [Primary preprint record](https://arxiv.org/abs/1708.02736): total-variation penalization and change-point selection in high-dimensional piecewise VAR. Cited explicitly as a 2017 preprint; no journal publication or online guarantee is inferred. |
| johnson2013hsmm | [JMLR BibTeX](https://www.jmlr.org/papers/v14/johnson13a.bib) | [JMLR article](https://www.jmlr.org/papers/v14/johnson13a.html) and [arXiv record](https://arxiv.org/abs/1203.1365): explicit durations relax ordinary geometric state durations. The paper is not cited as a solution to overlap-induced emission dependence. |
| hindriks2016sliding | DOI content negotiation for [10.1016/j.neuroimage.2015.11.055](https://doi.org/10.1016/j.neuroimage.2015.11.055) | [Primary article in PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC4758830/) and [PubMed metadata](https://pubmed.ncbi.nlm.nih.gov/26631813/): appropriate statistical testing of windowed dynamic connectivity. Used as a methodological fMRI precedent, not direct calcium validation. |
| peixoto2018weighted | DOI content negotiation for [10.1103/PhysRevE.97.012306](https://doi.org/10.1103/PhysRevE.97.012306) | [Author preprint record with journal reference](https://arxiv.org/abs/1708.01432): Bayesian weighted block models include signed weights. The primary record confirms article number 012306. A temporal, directed, uncertainty-aware extension is proposed separately, not attributed wholesale to this source. |
| benjamini2001control | DOI content negotiation for [10.1214/aos/1013699998](https://doi.org/10.1214/aos/1013699998) | [Authors' institutional record and abstract](https://cris.tau.ac.il/en/publications/the-control-of-the-false-discovery-rate-in-multiple-testing-under/) and [author publication list](https://www.math.tau.ac.il/~yekutiel/papers/papers.html): dependence conditions and conservative modification. Institutional export confirms pages 1165–1188. The publisher/author PDF endpoints intermittently failed, so full-proof rederivation is not claimed. |

DOI exports and publisher pages are two verification surfaces but are not
independent scientific replications. For JMLR records, the matching author arXiv
record supplies a second identity check. No bibliography entry was composed from
memory.

## Inherited records specifically checked during revision

- matias2017dsbm: [author preprint](https://arxiv.org/abs/1506.07464) checked for
  dynamic memberships and weighted graph modeling; DOI export retrieved.
  The export uses the online-first year 2016. The [publisher issue record](https://academic.oup.com/jrsssb/article-abstract/79/4/1119/7040669)
  identifies volume 79(4), September **2017**, pp. 1119–1141, so the inherited
  issue-year convention is retained.
- linderman2017rslds: [PMLR record, abstract, and BibTeX](https://proceedings.mlr.press/v54/linderman17a.html)
  checked for state/observation-dependent transitions. No neuronal causal
  identification claim is borrowed.
- adedayo2025cgc: [arXiv record](https://arxiv.org/abs/2501.02672) checked for
  the marginal/conditional distinction and richer c-GC* conditioning.
  Revision metadata were updated from May to July 2026. The existing arXiv
  citation is retained; the linked journal DOI is not silently substituted.
- kato2015global: retained for the original recording lineage. The 2025 dLDS
  primary article independently describes immobilization and fictive-state
  annotation in that lineage. Exact correspondence between the project's
  pinned local files and the original annotation procedure remains a
  **data-provenance verification task**, not a gap to resolve by stronger wording.

Other inherited citations keep the prior audit's status. Their presence in this
file should not be read as a new content-level re-verification of every claim.

## Removed unsupported material

The in-preparation PLACEHOLDER_adedayo2026risingflanks record and its related-work
claim were removed from this revision. No unpublished source is used to justify
an established methodological advantage. The unqualified claim that a dynamic
connectivity-to-behavior framework is missing was replaced with an explicit
comparison to dLDS and other dynamical approaches.

## Integration checks

The revised introduction, related work, and conclusions cite 26 unique keys;
all resolve in the 117-entry bibliography, with no duplicate keys (checked on
2026-09-26). These counts apply to the framing files, not to the final integrated
manuscript while other sections are being revised.

The final build must verify all citation keys across the current main.tex and
included section files. Missing keys, placeholder citations, and duplicate keys
are release blockers. Compilation checks concern document integrity; they do not
establish empirical correctness, novelty, or the completeness of the literature
review. No biological results were generated for this revision.

Integrated check (2026-09-26): all 31 cited keys in the manuscript resolve;
there are no duplicate labels, undefined cross-reference targets, or cited
placeholders. The integrated Tectonic/BibTeX build succeeds. The log includes
an inherited lineno package encoding warning and minor underfull text boxes;
there are no missing-citation or undefined-reference warnings. The build
status does not certify implementation or scientific calibration.

## fastC-GC backend revision — 31 October 2026

Added `adedayo2026fastcgc`: S. A. Adedayo, “fastC-GC and fastC-GC*: Efficient RCCP-Guided Graph Estimation for Time Series”, arXiv:2610.37883v1 (27 October 2026), DOI [10.48550/arXiv.2610.37883](https://doi.org/10.48550/arXiv.2610.37883). Metadata and methods were checked against the [arXiv record](https://arxiv.org/abs/2610.37883) and [full-text sections 2.1–2.5](https://arxiv.org/html/2610.37883v1).

The original `adedayo2025cgc` citation is retained for the RCCP marginal/conditional decision rule and c-GC/c-GC* conditioning sets. The new citation supports the distinct standardized ridge-residual estimators, shared precision calculations, Schur downdates, and complete-shift FFT evaluation. The manuscript does not attribute numerical equivalence, universal test validity, or end-to-end effectome runtime gains to either paper. The signed self-history-retaining VAR readout remains this protocol's separate estimation step.

## Trace preservation and conditioning depth — 31 October 2026

- Refreshed and cited the existing `adedayo2026bss` record: S. A. Adedayo, *Blind Source Separation Can Distort Behavior and Connectivity Analyses of Calcium Transients*, arXiv:2608.00655v1 (1 August 2026), DOI [10.48550/arXiv.2608.00655](https://doi.org/10.48550/arXiv.2608.00655). Checked the [record](https://arxiv.org/abs/2608.00655) and [full text](https://arxiv.org/html/2608.00655v1). The related-work and preprocessing passages cite it for variable preservation and matched controls, without generalizing its findings into universal BSS harm.
- Refreshed and cited the existing `adedayo2026conditioning` record: S. A. Adedayo, *Conditioning-Depth Diagnostics for Hidden Memory in Temporal Causal Discovery*, arXiv:2606.01214v2 (30 July 2026), DOI [10.48550/arXiv.2606.01214](https://doi.org/10.48550/arXiv.2606.01214). Checked the [record](https://arxiv.org/abs/2606.01214) and [full-text methods](https://arxiv.org/html/2606.01214v2). The diagnostic increases conditioning depth while holding the reported lag fixed. Its published evaluation uses c-GC/c-GC*; the manuscript marks application to fastC-GC/fastC-GC* as an extension requiring its own calibration. Removed the unused stale-title duplicate `adedayo2026markovianity` for this same arXiv identifier.

The integrated manuscript now cites 34 unique keys, including the original c-GC basis, the fast estimator, and these two diagnostic/preprocessing studies.

## Method synchronization integrity — 1 November 2026

The update against code revision `62b1a20` changes no bibliography records and
retains all 34 cited keys, including the original c-GC, fastC-GC, BSS, and
conditioning-depth papers. All 51 source labels are unique and every citation
and cross-reference resolves. Tectonic/BibTeX rebuilds the 34-page manuscript
without undefined citations/references, duplicate labels, overfull boxes, or
TeX errors. The inherited `lineno` encoding warning and minor underfull boxes
remain. PDF text confirms that the removed version/submission notices have
not returned. Completed raw development checks are labeled separately from
publication-scale validation and biological evaluation.

# Independent-review implementation

Synchronized with package `dev` revision `62b1a20` on 1 November 2026.

The review's recommendations have been translated into executable development procedures. Community detection is retained. Roles, whole-graph states, structural communities, and intervention-response groups remain distinct scientific targets.

| Review concern | Implemented response | Interpretation |
| --- | --- | --- |
| A fixed three-state default can imply regimes without evidence | The default nested state workflow includes a one-state alternative; state codes compete with constant and continuous predictors | Multi-state selection alone does not establish neural regimes |
| K-means imposes one assignment geometry | A regularized diagonal Gaussian mixture supplies a flexible competitor with frozen held-out probabilities; K-means remains the baseline | Probabilities condition on estimated graphs and do not propagate graph-estimation error |
| Misleading causal-kernel provenance | Effective representation, algorithm, and distance are recorded independently; the legacy RBF map is identified as such | A dependence-contribution causal kernel is not claimed or approximated |
| Full-series fitting can contaminate prospective state evaluation | Chronological inner and outer splits purge shared raw histories; scaling, PCA, state codebooks and forecast parameters are fitted within training data | The evaluator tests future-graph predictive compression, with upstream graph/preprocessing provenance a separate requirement |
| Transition significance can recycle a chosen segmentation | Frozen training transition counts/parameters are scored on untouched codes; prospective output carries no label-shuffle regime p-value | Descriptive sequence randomizations do not validate regime discovery |
| Role features duplicate the same edge information | Default features use one signed incoming/outgoing profile per lag; legacy expanded features are explicit | Persistent role similarity remains different from structural community membership |
| Generic clustering can obscure structural organization | Installed Leiden remains available as an optional graph-organization comparator | Absolute weights remove sign; symmetrization removes direction, and these transformations remain recorded |
| Neural prediction may select representations differently from behavior prediction | Default `neural_dynamics` selection is complemented by a declared `endpoint_prediction` sensitivity, using purged inner endpoint losses | Each procedure is evaluated on untouched outer data and supports its own predictive claim |
| Apparent states can arise from estimation, observation changes, and temporal mixing | A raw-data calibration suite reruns graph estimation and nested selection across seven scenarios and history/dwell grids | A finite design frequency is a development diagnostic, not validated population error control |

## State-analysis implementation

The backend in `../effectome-to-behavior/src/effectome/dynamics/graph_states.py` fits signed, lag-resolved features. Default PCA uses at most eight components, capped by training sample count and feature dimension; it does not estimate numerical rank. The Gaussian-mixture competitor uses diagonal covariances, regularization `1e-3`, five initializations, and a 200-iteration ceiling. Failed fits remain unavailable. Optional externally supplied feature reliability weights require an independent training-only calibration source; their existence does not make default unit-variance scaling uncertainty-aware.

`dynamics/state_evaluation.py` pairs a current graph history with a target graph whose complete history begins after the current history ends. Inner selection compares constant prediction, continuous ridge prediction, and K-means/Gaussian-mixture membership predictors for the same future fitted graph features. State counts are drawn from `{1,2,3,4,6}` and ridge penalties from `{0.1,1,10}`. The relative-gain setting is `0.01`: the best multi-code inner loss must be strictly below 99% of the better constant/continuous inner loss. Outer validation is recorded separately against that inner-selected baseline; inner selection can persist when the outer gain fails. These are development compression criteria, not biological practical-effect thresholds. The chosen procedure is refitted on outer training data and scored once on outer targets. Lack of sufficient purged pairs yields an unavailable result.

Default notebook and `pipeline/02_dynamics.py` entry points use this prospective evaluator. The outer test and inner validation fractions are each 0.25, with at least four training pairs after each purge. Training scaling/PCA uses the union of predictor and target indices within training pairs. Frozen transition counts use that outer-training union; held-out transition scores use outer-test predictor indices and reset adjacency at gaps. Full-series summaries require an explicit descriptive scope. Existing notebook outputs were preserved and may predate the updated code; no biological notebook analysis was rerun for this manuscript update.

## Raw-data development checks

`experiments/state_calibration.py` and `pipeline/10_state_calibration.py` provide:

- Fixed interactions with stationary observations.
- Fixed interactions with changing innovation variance.
- Fixed interactions with changing calcium kinetics.
- Smooth coefficient drift without discrete states.
- Recurrent discrete regimes.
- Nonrecurring epochs.
- Nonlinear recurrent dynamics.

The development profile crosses history and dwell lengths, reruns the raw pipeline per draw, and records input/configuration/implementation hashes. The same raw recording under different histories is treated as a paired design. Reports retain unavailable draws and include state recovery where defined, change-detection delay, missed/extra transitions, prediction errors, and conditional assignment entropy. Multi-state selection in no-discrete-regime generators is reported as a design-conditional diagnostic, not an empirical estimate of general causal-discovery validity.

From the package directory, a bounded execution check is available through:

```bash
.venv/bin/python pipeline/10_state_calibration.py --profile smoke --output-dir outputs/state-calibration/review-smoke
```

The untruncated `development` profile is a development experiment, not the publication-scale suite specified in the manuscript. The saved seven-draw smoke report has all draws available. Three of four no-discrete-regime draws selected multiple codes on inner validation, and two exceeded the outer 1% compression margin. The manuscript reports this finite diagnostic separately from biological claims. Its smoke thresholds are alpha=beta=0.05 (production beta=0.005), with lag 1, three neurons, 960 samples at 1 Hz, history 32, stride 16 and requested dwell 64; recurrent schedules alternate at fixed dwell. The development profile specifies 189 evaluations on 63 raw draws (seven scenarios × three dwells × three replicates, each under three histories), not 189 independent recordings.

## Remaining scientific work

The implementation does not supply independent animal replication, verified endpoint lineage, independently measured kinematics, or a justified practical-effect threshold. Publication-scale null/recovery experiments, observation-model stress tests, and independent-animal evaluation remain requirements for the corresponding claims. Full graph uncertainty still needs propagation through resampling or an explicit measurement model.

The Markham dependence-contribution kernel remains a separate research comparator requiring a defined raw-data representation, an inductive reference, and dependence-aware calibration. Treatment-response causal K-means requires identified intervention-response functions and appropriate data. Neither is introduced by renaming the RBF representation or changing the clustering optimizer.

The primary M0/M1 comparison continues to test the incremental value of continuous graph features without mandatory states or groups. Structural community detection is retained as an optional analysis, with temporal roles reported separately.

## Manuscript integrity

The methodology and limitations sections, manuscript README, and revision notes were updated. Existing citations were retained; no new references or biological results were invented. LaTeX/BibTeX compilation checks document integrity separately from scientific validation. The integrated package verification is recorded by the parent implementation workflow.

## Notebook readiness and remaining benchmark scope

All default manifold notebooks use cross-fitted classical PCA (three components, five folds). Faithful BunDLe remains optional; its full-recording reference is retrospective. V2a state notebooks checkpoint insufficient-data results and clear stale state/transition outputs; linking propagates the reason. The primary endpoint and owned-feature analyses remain independent of states.

Role inference and owned-feature construction default to one role. Incoming/outgoing lag profiles retain shared neighbor-coordinate slots with zero self-coefficients; no strength/balance/positive-negative duplicates are appended. Structural Leiden remains optional through installed igraph/leidenalg.

The current primary reference and `endpoint_prediction` sensitivity use per-history sparse VAR; the latter jointly tunes sparsity and decoder regularization on matched chronological splits with future-target purging. The compact M0 is last activity plus history means/standard deviations. The full activity/behavior/input-history baseline and comparisons across all proposed graph families remain benchmark requirements.

Engineering verification at the cited code revision: 378 tests passed, one optional PyTorch test skipped; all 173 notebook bootstrap/configuration checks, 543 parsed code cells, Ruff, mypy over 77 files, locked environment sync and installed-package checks passed. These do not certify biological performance. See `../effectome-to-behavior/NOTEBOOK_READINESS.md` for the supplied-data preflight and `../effectome-to-behavior/exec_order.md` for execution dependencies.

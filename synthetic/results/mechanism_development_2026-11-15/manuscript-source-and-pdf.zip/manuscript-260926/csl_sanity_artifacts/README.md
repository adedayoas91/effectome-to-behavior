# Frozen four-method native graph sanity evidence — 15 November 2026

This bundle preserves the actual 24-fit result from
`effectome-to-behavior/synthetic/results/four_csl_sanity_2026-11-15/`.
It contains only the four imported CSL methods. The former multi-estimator
result bundles have been removed from the manuscript; raw historical application
outputs remain separate audit records. Pure generating controls are retained in
`simulation_control_artifacts/` without fitted estimator outcomes.

- `sanity.json`: native evidence, package provenance, exact method settings,
  input/comparison fingerprints, seed outcomes, and explicit claim scope.
- `provenance.json`: original execution and noninteractive figure-export record.
- `seed-metrics.csv` and `pairwise-agreement.csv`: exact descriptive outcomes.
- `stats-appendix.md`: seed-level statistical scope and exact null intervals.
- `analysis-report.md`: original generated analysis summary.
- Two PDF figures: byte-for-byte copies of the saved noninteractive exports.
- `recovery-summary.tex`: generated from `seed-metrics.csv` for the manuscript.
- `artifact-manifest.json`: SHA-256 hashes of copied files and the generated table.

All four methods recovered the two planted chain edges and an empty null graph
at each of three independent data seeds. These outcomes support only native
graph-recovery sanity on the declared directly observed linear Gaussian process.
They do not validate manifold transitions, driver recovery, or biological
necessity. The four methods constitute one estimator family; native support is
unsigned, and upstream conventional CPU permutations are not fully seed-controlled.

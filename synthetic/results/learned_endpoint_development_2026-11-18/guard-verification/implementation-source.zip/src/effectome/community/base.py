"""Base class, config, and registry for community detection (Stage 4)."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass, field, fields, is_dataclass
from typing import Any, cast

import numpy as np

from effectome.data_module import schema as schema_module
from effectome.data_module.schema import CommunitySeries, ConnectivitySeries

logger = logging.getLogger(__name__)


def _community_provenance(series: ConnectivitySeries, method: str) -> Any:
    upstream = series.provenance
    metadata = {
        **dict(upstream.metadata),
        "upstream_stage": upstream.stage,
        "upstream_fit_scope_id": upstream.fit_scope_id,
        "upstream_split_manifest_hash": upstream.split_manifest_hash,
        "ownership_contract": "full_series_community_fit_requires_separate_outer_scope",
        "connectivity_method": series.method,
        "directed": bool(series.directed),
        "signed": bool(series.signed),
        "weighted": bool(series.weighted),
        "storage": series.storage,
        "weight_semantics": series.weight_semantics,
        "connectivity_diagnostics": dict(series.diagnostics),
    }
    prov_cls = cast(type[Any] | None, getattr(schema_module, "ArtifactProvenance", None))
    if prov_cls is None:
        return None
    try:
        if is_dataclass(prov_cls):
            supported = {item.name for item in fields(prov_cls)}
            payload = {
                item.name: getattr(upstream, item.name)
                for item in fields(upstream)
                if item.name in supported
            }
            payload.update(
                {
                    "stage": "community",
                    "configuration_id": method,
                    "metadata": metadata,
                    "fit_scope_id": None,
                    "split_manifest_hash": None,
                    "fitted_raw_intervals": (),
                    "claim_eligibility": "development_only",
                    "axis_conventions": {
                        "labels": "anchor,neuron",
                    },
                }
            )
            return prov_cls(**{key: value for key, value in payload.items() if key in supported})
        return prov_cls(stage="community", configuration_id=method, metadata=metadata)
    except Exception:
        logger.debug("Falling back to CommunitySeries provenance default", exc_info=True)
        return None


def build_community_series(
    *,
    series: ConnectivitySeries,
    labels: np.ndarray,
    method: str,
    n_communities_per_window: np.ndarray,
    extras: dict[str, Any] | None = None,
) -> CommunitySeries:
    """Construct a CommunitySeries while remaining compatible with older schema revisions."""
    kwargs: dict[str, Any] = {
        "labels": labels.astype(np.int64),
        "method": method,
        "n_communities_per_window": np.asarray(n_communities_per_window, dtype=int),
        "anchors": list(series.anchors),
        "window_starts": np.asarray(series.window_starts, dtype=int),
        "signed": bool(series.signed),
        "directed": bool(series.directed),
        "metadata": {
            "connectivity_diagnostics": dict(series.diagnostics),
            "connectivity_method": series.method,
        },
    }
    provenance = _community_provenance(series, method)
    if provenance is not None:
        kwargs["provenance"] = provenance
    if extras:
        kwargs.update(extras)

    supported = {item.name for item in fields(CommunitySeries)}
    return CommunitySeries(**{key: value for key, value in kwargs.items() if key in supported})


@dataclass(frozen=True)
class CommunityConfig:
    """Configuration for community detection.

    Attributes:
        name: Registry key ('leiden', 'markov_stability', 'temporal').
        resolution: Resolution parameter (higher -> more, smaller communities).
        symmetrize: Symmetrize directed matrices before detection.
        use_absolute: Use absolute weights before detection. This preserves the
            current modularity-style magnitude baseline while allowing signed
            community experiments.
        weight_threshold: Drop edges below this absolute weight before detection.
        seed: Random seed for stochastic detectors.
        extra: Method-specific options (e.g. temporal interlayer coupling).
    """

    name: str = "leiden"
    resolution: float = 1.0
    symmetrize: bool = True
    use_absolute: bool = True
    weight_threshold: float = 0.0
    seed: int = 42
    extra: dict = field(default_factory=dict)


class CommunityDetector(ABC):
    """Partition neurons into communities for each connectivity matrix."""

    def __init__(self, cfg: CommunityConfig) -> None:
        self.cfg = cfg

    def _prepare(self, w: np.ndarray) -> np.ndarray:
        a = np.abs(w) if self.cfg.use_absolute else np.array(w, copy=True)
        if self.cfg.symmetrize:
            a = 0.5 * (a + a.T)
        if self.cfg.weight_threshold > 0:
            a = np.where(np.abs(a) >= self.cfg.weight_threshold, a, 0.0)
        np.fill_diagonal(a, 0.0)
        return a

    @abstractmethod
    def detect_one(self, matrix: np.ndarray) -> np.ndarray:
        """Return integer community labels, shape (N,), for one N x N matrix."""

    def run(
        self,
        series: ConnectivitySeries,
        *,
        progress_callback: Callable[[int, int], None] | None = None,
    ) -> CommunitySeries:
        """Detect communities per window -> CommunitySeries."""
        labels_per_window = []
        total = int(series.n_windows)
        for index, window in enumerate(series.matrices):
            labels_per_window.append(self.detect_one(self._prepare(window)))
            if progress_callback is not None:
                progress_callback(index + 1, total)
        labels = np.stack(labels_per_window)
        counts = np.array([len(np.unique(row)) for row in labels])
        logger.info("Detected communities for %d windows (%s)", series.n_windows, self.cfg.name)
        backend = getattr(self, "_last_backend", self.cfg.name)
        return build_community_series(
            series=series,
            labels=labels.astype(np.int64),
            method=self.cfg.name,
            n_communities_per_window=counts,
            extras={
                "metadata": {
                    "connectivity_diagnostics": dict(series.diagnostics),
                    "connectivity_method": series.method,
                    "actual_backend": backend,
                    "input_transform": {
                        "use_absolute": bool(self.cfg.use_absolute),
                        "symmetrize": bool(self.cfg.symmetrize),
                        "weight_threshold": float(self.cfg.weight_threshold),
                    },
                    "supported_input": "symmetric_nonnegative"
                    if self.cfg.use_absolute and self.cfg.symmetrize
                    else "explicit_transform_recorded",
                }
            },
        )


COMMUNITY_REGISTRY: dict[str, type[CommunityDetector]] = {}


def register_community(name: str):
    """Class decorator registering a `CommunityDetector` under `name`."""

    def deco(cls: type[CommunityDetector]) -> type[CommunityDetector]:
        if name in COMMUNITY_REGISTRY:
            raise ValueError(f"community '{name}' already registered")
        COMMUNITY_REGISTRY[name] = cls
        return cls

    return deco


def CommunityFactory(cfg: CommunityConfig) -> CommunityDetector:
    """Instantiate the community detector selected by `cfg.name`."""
    if cfg.name not in COMMUNITY_REGISTRY:
        raise KeyError(f"unknown community '{cfg.name}'; available: {sorted(COMMUNITY_REGISTRY)}")
    return COMMUNITY_REGISTRY[cfg.name](cfg)

"""Cluster the sequence of connectivity matrices into recurring dataset-global states.

The dynamic effectome {W_1..W_K} is treated as a trajectory in graph space, and clustering it
into recurring states (regimes) is *Fréchet quantization*: pick a codebook and assignment that
minimize summed squared distance under a chosen graph metric (see ``metrics.py``).

This implementation is dataset-global and fit/transform-aware:

* fit-time standardization is learned only on the fit subset and reused for held-out assignment;
* state centroids/medoids are learned once and reused by :meth:`GraphStateModel.transform`;
* recording/gap boundaries are inferred from anchor metadata or window starts and carried into
  downstream transition modeling.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

import numpy as np
from sklearn.cluster import KMeans, SpectralClustering
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from sklearn.mixture import GaussianMixture

from effectome.data_module.schema import ConnectivitySeries, TemporalAnchor

from .graph_similarity import GRAPH_SIMILARITY_METRICS
from .graph_similarity_states import assign_similarity_states, fit_similarity_states
from .metrics import expm_sym, kmedoids, log_euclidean_features, logm_spd, pairwise_distances, vectorize

logger = logging.getLogger(__name__)

FEATURE_METRICS = ("frobenius", "cosine", "log_euclidean")
KERNEL_METRICS = ("causal_kernel", "legacy_rbf")
DISTANCE_METRICS = ("affine_invariant", "gromov_wasserstein")


@dataclass(frozen=True)
class GraphStateConfig:
    """Configuration for connectivity-state discovery.

    Attributes:
        n_states: Number of states K (ignored if select_k is True).
        select_k: Signed-lag models require caller-owned inner predictive losses including K=1.
            Legacy descriptive models select by silhouette over [k_min, k_max].
        k_min: Minimum K when selecting.
        k_max: Maximum K when selecting.
        standardize: Z-score features before clustering (fit subset only).
        metric: Graph-space geometry. Binary-support similarities use frozen graph medoids;
            signed-lag models use fitted feature coordinates and record the actual distance.
        eps: Eigenvalue floor for SPD projection (log_euclidean / affine_invariant).
        gw_epsilon: Entropic regularization for Gromov-Wasserstein.
        gw_max_iter: Outer iterations for Gromov-Wasserstein.
        kernel_gamma: RBF bandwidth multiplier for the legacy descriptive graph affinity.
        boundary_gap_factor: Gaps larger than this multiple of the nominal stride start a new
            transition segment when explicit recording ids are unavailable.
        seed: Random seed for KMeans / spectral clustering / k-medoids.
    """

    n_states: int = 3
    select_k: bool = False
    k_min: int = 2
    k_max: int = 8
    standardize: bool = True
    metric: str = "causal_kernel"
    eps: float = 1e-6
    gw_epsilon: float = 0.05
    gw_max_iter: int = 200
    kernel_gamma: float = 1.0
    boundary_gap_factor: float = 3.0
    seed: int = 42
    feature_representation: str = "legacy"
    assignment: str = "legacy"
    pca_components: int | None = None
    mixture_reg_covar: float = 1e-3
    mixture_n_init: int = 5
    mixture_max_iter: int = 200
    analysis_scope: str = "descriptive"
    wl_iterations: int = 2

    def __post_init__(self) -> None:
        if self.assignment not in {"legacy", "kmeans", "gaussian_mixture", "kmedoids"}:
            raise ValueError("assignment must be 'legacy', 'kmeans', 'gaussian_mixture' or 'kmedoids'")
        if type(self.wl_iterations) is not int or self.wl_iterations < 0:
            raise ValueError("wl_iterations must be a nonnegative integer")
        if not np.isfinite(self.mixture_reg_covar) or self.mixture_reg_covar <= 0:
            raise ValueError("mixture_reg_covar must be finite and positive")
        if self.mixture_n_init < 1 or self.mixture_max_iter < 1:
            raise ValueError("mixture_n_init and mixture_max_iter must be positive")
        if self.analysis_scope not in {"descriptive", "prospective"}:
            raise ValueError("analysis_scope must be 'descriptive' or 'prospective'")


@dataclass
class GraphStateModel:
    """Result of dataset-global connectivity-state clustering.

    Attributes:
        labels: State label per window, shape (K_windows,).
        centroids: State centroid/medoid matrices, shape (n_states, N, N).
        n_states: Number of states.
        silhouette: Silhouette-like score of the chosen clustering on the fit subset.
        metric: Graph metric used for clustering.
        window_starts: Window start indices for the series labels.
        feature_centroids: Optional centroids in feature space used for held-out assignment.
        feature_mean: Fit-time feature mean for held-out standardization.
        feature_scale: Fit-time feature std for held-out standardization.
    medoid_matrices: Optional medoid graphs used for distance-based assignment.
        fit_indices: Indices used to fit the state model.
        boundary_indices: Start indices of independent transition segments.
    """

    labels: np.ndarray
    centroids: np.ndarray
    n_states: int
    silhouette: float
    metric: str
    window_starts: np.ndarray
    feature_centroids: np.ndarray | None = None
    feature_mean: np.ndarray | None = None
    feature_scale: np.ndarray | None = None
    medoid_matrices: np.ndarray | None = None
    fit_indices: np.ndarray | None = None
    boundary_indices: np.ndarray | None = None
    feature_representation: str = "legacy"
    assignment: str = "legacy"
    edge_indices: np.ndarray | None = None
    lag_indices: np.ndarray | None = None
    lag_count: int | None = None
    n_nodes: int | None = None
    pca_components: np.ndarray | None = None
    pca_mean: np.ndarray | None = None
    descriptive_centroids: np.ndarray | None = None
    lag_centroids: np.ndarray | None = None
    graph_schema: tuple | None = None
    selection_loss: float | None = None
    eps: float = 1e-6
    gw_epsilon: float = 0.05
    gw_max_iter: int = 200
    mixture: GaussianMixture | None = None
    membership_probabilities: np.ndarray | None = None
    feature_weights: np.ndarray | None = None
    effective_algorithm: str = "legacy"
    effective_distance: str = "legacy"
    requested_metric: str | None = None
    analysis_scope: str = "descriptive"
    inductive_assignment_valid: bool = True
    lagged_medoid_matrices: np.ndarray | None = None
    medoid_indices: np.ndarray | None = None
    wl_iterations: int = 2

    def transform_features(self, series: ConnectivitySeries | np.ndarray) -> np.ndarray:
        """Apply only the fitted feature vocabulary, scaling, weights and PCA."""
        if self.metric in GRAPH_SIMILARITY_METRICS:
            raise ValueError("support-similarity models expose graph assignments, not Euclidean coordinates")
        if self.feature_representation == "signed_lag_offdiag":
            if self.graph_schema != graph_schema(series):
                raise ValueError("registered graph schema mismatch")
            raw, _, _, _, _ = _signed_lag_offdiag_features(
                series,
                edge_indices=self.edge_indices,
                lag_indices=self.lag_indices,
                n_nodes=self.n_nodes,
                lag_count=self.lag_count,
            )
        else:
            if self.metric not in FEATURE_METRICS + KERNEL_METRICS:
                raise ValueError("distance-based models do not expose fitted Euclidean feature coordinates")
            matrices = series.matrices if isinstance(series, ConnectivitySeries) else np.asarray(series)
            raw = _raw_features_for(
                matrices, self.metric, GraphStateConfig(metric=self.metric, eps=self.eps)
            )
        features = _Standardizer(self.feature_mean, self.feature_scale).transform(raw)
        if self.feature_weights is not None:
            features = features * np.sqrt(self.feature_weights)
        return _transform_pca(features, components=self.pca_components, mean=self.pca_mean)

    def transform_proba(self, series: ConnectivitySeries | np.ndarray) -> np.ndarray:
        """Return mixture responsibilities or hard one-hot quantizer assignments.

        Mixture responsibilities condition on the fitted plug-in graphs and
        model; they do not propagate connectivity-estimation uncertainty.
        """
        if self.analysis_scope == "prospective" and not self.inductive_assignment_valid:
            raise ValueError("legacy spectral assignment has no validated inductive extension")
        if self.mixture is not None:
            return np.asarray(self.mixture.predict_proba(self.transform_features(series)), dtype=np.float64)
        return np.eye(self.n_states, dtype=np.float64)[self.transform(series)]

    @property
    def assignment_entropy(self) -> np.ndarray | None:
        """Conditional membership entropy; hard K-means assignments have zero entropy."""
        if self.membership_probabilities is None:
            return None
        probabilities = self.membership_probabilities
        return -np.sum(probabilities * np.log(np.maximum(probabilities, np.finfo(float).tiny)), axis=1)

    def transform(
        self,
        series: ConnectivitySeries | np.ndarray,
        *,
        window_starts: np.ndarray | None = None,
    ) -> np.ndarray:
        """Assign labels to new matrices without refitting the state model."""
        if self.feature_representation == "signed_lag_offdiag" or self.metric in GRAPH_SIMILARITY_METRICS:
            return assign_graph_states(self, series)
        matrices = series.matrices if isinstance(series, ConnectivitySeries) else np.asarray(series)
        # `window_starts` is accepted for backward compatibility, but held-out assignment must
        # not mutate the fitted model's training coordinates or boundary metadata.
        _ = series.window_starts if isinstance(series, ConnectivitySeries) else window_starts
        return assign_graph_states(self, matrices)


@dataclass(frozen=True)
class _Standardizer:
    mean: np.ndarray | None
    scale: np.ndarray | None

    def transform(self, features: np.ndarray) -> np.ndarray:
        if self.mean is None or self.scale is None:
            return features
        return (features - self.mean) / self.scale


def _series_metadata(series: ConnectivitySeries) -> dict:
    metadata = getattr(series, "metadata", None)
    if isinstance(metadata, dict):
        return metadata
    return {}


def graph_schema(series: ConnectivitySeries | np.ndarray, *, strict: bool = False) -> tuple | None:
    """Registered identity and physical units; missing metadata remains descriptive only."""
    if not isinstance(series, ConnectivitySeries):
        if strict:
            raise ValueError("registered graph schema requires a ConnectivitySeries")
        return None
    metadata = series.diagnostics
    keys = ("node_ids", "physical_lags", "representation_units")
    if not all(key in metadata for key in keys):
        if strict or any(key in metadata for key in keys):
            raise ValueError("graph schema requires node_ids, physical_lags and representation_units")
        return None
    nodes = tuple(metadata["node_ids"])
    lags = tuple(float(x) for x in metadata["physical_lags"])
    units = str(metadata["representation_units"])
    tensor = _lagged_tensor_from_series(series)
    if (len(nodes) != tensor.shape[2] or len(set(nodes)) != len(nodes)
            or len(lags) != tensor.shape[1] or not units
            or not np.all(np.isfinite(lags)) or np.any(np.asarray(lags) <= 0)
            or np.any(np.diff(lags) <= 0)):
        raise ValueError("invalid registered graph schema")
    return nodes, lags, units


def _boundary_indices_from_anchors(anchors: list[TemporalAnchor]) -> np.ndarray:
    """Infer segment starts from typed temporal anchors."""
    if not anchors:
        return np.asarray([0], dtype=int)

    def _key(anchor: TemporalAnchor) -> tuple[str, str, str | None, str | None, str | None]:
        return (
            anchor.dataset_id,
            anchor.recording_id,
            anchor.animal_id,
            anchor.session_id,
            anchor.segment_id,
        )

    boundaries = [0]
    for idx in range(1, len(anchors)):
        prev = anchors[idx - 1]
        cur = anchors[idx]
        if (
            _key(cur) != _key(prev)
            or cur.gap_before
            or prev.gap_after
            or cur.bad_frame_before
            or prev.bad_frame_after
        ):
            boundaries.append(idx)
    return np.asarray(boundaries, dtype=int)


def infer_boundary_indices(
    window_starts: np.ndarray,
    *,
    recording_ids: np.ndarray | None = None,
    gap_factor: float = 3.0,
) -> np.ndarray:
    """Infer independent transition segments from pooled window starts / recording ids."""
    starts = np.asarray(window_starts, dtype=int)
    if starts.ndim != 1:
        raise ValueError("window_starts must be a 1D array")
    boundaries = [0]
    if starts.size <= 1:
        return np.asarray(boundaries, dtype=int)

    if recording_ids is not None:
        rec = np.asarray(recording_ids)
        if rec.shape[0] != starts.shape[0]:
            raise ValueError("recording_ids must match window_starts length")
        for idx in range(1, len(starts)):
            if rec[idx] != rec[idx - 1]:
                boundaries.append(idx)
        return np.asarray(boundaries, dtype=int)

    diffs = np.diff(starts)
    positive = diffs[diffs > 0]
    nominal_stride = float(np.median(positive)) if positive.size else 1.0
    gap_threshold = max(gap_factor * nominal_stride, nominal_stride + 1.0)
    for idx, delta in enumerate(diffs, start=1):
        if delta <= 0 or delta > gap_threshold:
            boundaries.append(idx)
    return np.asarray(boundaries, dtype=int)


def boundary_indices_for_series(
    series: ConnectivitySeries,
    *,
    gap_factor: float = 3.0,
) -> np.ndarray:
    """Infer boundary indices from typed anchors first, then fall back to provenance or starts."""
    anchors = list(getattr(series, "anchors", []))
    if anchors:
        if len(anchors) != series.n_windows:
            raise ValueError("series.anchors must align 1:1 with series windows")
        return _boundary_indices_from_anchors(anchors)

    metadata = _series_metadata(series)
    recording_ids = metadata.get("recording_ids")
    return infer_boundary_indices(
        series.window_starts,
        recording_ids=None if recording_ids is None else np.asarray(recording_ids),
        gap_factor=gap_factor,
    )


def _fit_standardizer(features: np.ndarray, standardize: bool) -> tuple[np.ndarray, _Standardizer]:
    if not standardize:
        return features, _Standardizer(None, None)
    mean = features.mean(axis=0, keepdims=True)
    scale = features.std(axis=0, keepdims=True)
    scale[scale == 0] = 1.0
    return (features - mean) / scale, _Standardizer(mean=mean, scale=scale)


def _legacy_rbf_raw_features(matrices: np.ndarray) -> np.ndarray:
    pos = np.maximum(matrices, 0.0)
    neg = np.maximum(-matrices, 0.0)
    return np.concatenate(
        [
            vectorize(matrices),
            vectorize(pos),
            vectorize(neg),
            pos.sum(axis=2),
            neg.sum(axis=2),
            pos.sum(axis=1),
            neg.sum(axis=1),
        ],
        axis=1,
    )


def _rbf_affinity(features: np.ndarray, gamma: float) -> np.ndarray:
    sq = np.sum(features**2, axis=1)
    d2 = np.maximum(sq[:, None] + sq[None, :] - 2.0 * (features @ features.T), 0.0)
    scale = float(np.median(d2[d2 > 0])) if np.any(d2 > 0) else 1.0
    eff_gamma = gamma / max(scale, 1e-12)
    affinity = np.exp(-eff_gamma * d2)
    np.fill_diagonal(affinity, 1.0)
    return affinity


def _raw_features_for(matrices: np.ndarray, metric: str, cfg: GraphStateConfig) -> np.ndarray:
    if metric == "log_euclidean":
        return log_euclidean_features(matrices, cfg.eps)
    if metric == "cosine":
        feats = vectorize(matrices)
        norms = np.linalg.norm(feats, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return feats / norms
    if metric == "frobenius":
        return vectorize(matrices)
    if metric in KERNEL_METRICS:
        return _legacy_rbf_raw_features(matrices)
    raise ValueError(f"metric '{metric}' does not use direct features")


def _assign_feature_labels(features: np.ndarray, centroids: np.ndarray) -> np.ndarray:
    d2 = np.sum((features[:, None, :] - centroids[None, :, :]) ** 2, axis=2)
    return np.argmin(d2, axis=1).astype(np.int64)


def _validate_fit_indices(fit_indices: np.ndarray | None, n_windows: int) -> np.ndarray:
    if fit_indices is None:
        return np.arange(n_windows, dtype=int)
    arr = np.asarray(fit_indices)
    if arr.ndim != 1:
        raise ValueError("fit_indices must be a 1D array")
    if not np.issubdtype(arr.dtype, np.integer):
        raise ValueError("fit_indices must contain integers")
    arr = arr.astype(int)
    if arr.size == 0:
        raise ValueError("fit_indices must be nonempty")
    if np.any(arr < 0) or np.any(arr >= n_windows):
        raise ValueError("fit_indices must be in bounds")
    if np.any(np.diff(arr) <= 0):
        raise ValueError("fit_indices must be unique and ordered")
    return arr


def _lagged_tensor_from_series(series: ConnectivitySeries | np.ndarray) -> np.ndarray:
    if isinstance(series, ConnectivitySeries):
        if series.lagged_matrices is not None:
            return np.asarray(series.lagged_matrices, dtype=np.float64)
        return np.asarray(series.matrices, dtype=np.float64)[:, np.newaxis, :, :]
    arr = np.asarray(series, dtype=np.float64)
    if arr.ndim == 3:
        return arr[:, np.newaxis, :, :]
    if arr.ndim == 4:
        return arr
    raise ValueError("graph state input must have shape (window,node,node) or (window,lag,node,node)")


def _signed_lag_offdiag_features(
    series: ConnectivitySeries | np.ndarray,
    *,
    edge_indices: np.ndarray | None = None,
    lag_indices: np.ndarray | None = None,
    n_nodes: int | None = None,
    lag_count: int | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, int, int]:
    lagged = _lagged_tensor_from_series(series)
    if lagged.ndim != 4 or lagged.shape[2] != lagged.shape[3]:
        raise ValueError("lag-resolved graph tensor must be (window,lag,node,node)")
    if not np.all(np.isfinite(lagged)):
        raise ValueError("graph-state features must be finite")
    observed_lags = int(lagged.shape[1])
    observed_nodes = int(lagged.shape[2])
    if lag_count is not None and observed_lags != lag_count:
        raise ValueError("lag schema mismatch for graph-state assignment")
    if n_nodes is not None and observed_nodes != n_nodes:
        raise ValueError("node schema mismatch for graph-state assignment")
    if edge_indices is None:
        mask = ~np.eye(observed_nodes, dtype=bool)
        edge_indices = np.argwhere(mask)
    if lag_indices is None:
        lag_indices = np.arange(observed_lags, dtype=int)
    edge_arr = np.asarray(edge_indices, dtype=int)
    lag_arr = np.asarray(lag_indices, dtype=int)
    if edge_arr.ndim != 2 or edge_arr.shape[1] != 2:
        raise ValueError("edge_indices must have shape (edge,2)")
    features = [
        lagged[:, lag, edge_arr[:, 0], edge_arr[:, 1]]
        for lag in lag_arr
    ]
    return np.concatenate(features, axis=1), edge_arr, lag_arr, observed_nodes, observed_lags


def _apply_pca(
    features: np.ndarray,
    *,
    pca_components: int | None,
    seed: int,
) -> tuple[np.ndarray, np.ndarray | None, np.ndarray | None]:
    if pca_components is None:
        return features, None, None
    if pca_components < 1:
        raise ValueError("pca_components must be positive when provided")
    n_components = min(int(pca_components), features.shape[0], features.shape[1])
    pca = PCA(n_components=n_components, random_state=seed)
    reduced = pca.fit_transform(features)
    return reduced, pca.components_.astype(np.float64), pca.mean_.astype(np.float64)


def _transform_pca(
    features: np.ndarray,
    *,
    components: np.ndarray | None,
    mean: np.ndarray | None,
) -> np.ndarray:
    if components is None:
        return features
    if mean is None:
        raise ValueError("pca_mean is required with pca_components")
    return (features - mean) @ components.T


def _centroids(
    matrices: np.ndarray,
    labels: np.ndarray,
    n_states: int,
    metric: str,
    eps: float,
    medoid_matrices: np.ndarray | None = None,
) -> np.ndarray:
    """Per-state centroid graph: arithmetic/log-Euclidean mean or medoid graph."""
    n_neurons = matrices.shape[1]
    out = []
    for state in range(n_states):
        members = matrices[labels == state]
        if medoid_matrices is not None:
            out.append(medoid_matrices[state])
        elif members.shape[0] == 0:
            out.append(np.zeros((n_neurons, n_neurons)))
        elif metric == "log_euclidean":
            mean_log = np.mean([logm_spd(w, eps) for w in members], axis=0)
            out.append(expm_sym(mean_log))
        else:
            out.append(members.mean(axis=0))
    return np.stack(out).reshape(n_states, n_neurons, n_neurons)


def _fit_kernel_path(
    train_matrices: np.ndarray,
    cfg: GraphStateConfig,
) -> tuple[np.ndarray, np.ndarray, _Standardizer, int, float]:
    """Spectral clustering on signed directed effectome features."""
    n = train_matrices.shape[0]
    raw = _raw_features_for(train_matrices, "legacy_rbf", cfg)
    feats, standardizer = _fit_standardizer(raw, cfg.standardize)
    affinity = _rbf_affinity(feats, cfg.kernel_gamma)
    ks = range(cfg.k_min, min(cfg.k_max, n - 1) + 1) if cfg.select_k else [cfg.n_states]
    best = None
    for k in ks:
        model = SpectralClustering(
            n_clusters=k,
            affinity="precomputed",
            assign_labels="kmeans",
            random_state=cfg.seed,
        ).fit(affinity)
        labels = model.labels_.astype(np.int64)
        score = silhouette_score(feats, labels) if 1 < len(np.unique(labels)) < n else 0.0
        logger.info("metric=%s K=%d silhouette=%.3f", cfg.metric, k, score)
        if best is None or score > best[0]:
            centroids = np.stack([feats[labels == state].mean(axis=0) for state in range(k)])
            best = (score, k, labels, centroids)
    score, k, labels, centroids = best  # type: ignore[misc]
    return labels, centroids, standardizer, int(k), float(score)


def _fit_feature_path(
    train_matrices: np.ndarray,
    cfg: GraphStateConfig,
) -> tuple[np.ndarray, np.ndarray, _Standardizer, int, float]:
    """KMeans in a Euclidean feature space (frobenius / cosine / log_euclidean)."""
    n = train_matrices.shape[0]
    raw = _raw_features_for(train_matrices, cfg.metric, cfg)
    feats, standardizer = _fit_standardizer(raw, cfg.standardize)
    ks = range(cfg.k_min, min(cfg.k_max, n - 1) + 1) if cfg.select_k else [cfg.n_states]
    best = None
    for k in ks:
        km = KMeans(n_clusters=k, random_state=cfg.seed, n_init=10).fit(feats)
        score = silhouette_score(feats, km.labels_) if 1 < k < n else 0.0
        logger.info("metric=%s K=%d silhouette=%.3f", cfg.metric, k, score)
        if best is None or score > best[0]:
            best = (score, k, km.labels_.astype(np.int64), km.cluster_centers_)
    score, k, labels, feature_centroids = best  # type: ignore[misc]
    return labels, feature_centroids, standardizer, int(k), float(score)


def _fit_distance_path(
    train_matrices: np.ndarray,
    cfg: GraphStateConfig,
) -> tuple[np.ndarray, np.ndarray, int, float]:
    """K-medoids on a precomputed distance matrix (affine_invariant / gromov_wasserstein)."""
    n = train_matrices.shape[0]
    dist = pairwise_distances(
        train_matrices,
        cfg.metric,
        eps=cfg.eps,
        gw_epsilon=cfg.gw_epsilon,
        gw_max_iter=cfg.gw_max_iter,
    )
    ks = range(cfg.k_min, min(cfg.k_max, n - 1) + 1) if cfg.select_k else [cfg.n_states]
    best = None
    for k in ks:
        labels, medoid_indices = kmedoids(dist, k, seed=cfg.seed)
        valid = 1 < len(np.unique(labels)) < n
        score = silhouette_score(dist, labels, metric="precomputed") if valid else 0.0
        logger.info("metric=%s K=%d silhouette=%.3f", cfg.metric, k, score)
        if best is None or score > best[0]:
            best = (score, k, labels.astype(np.int64), train_matrices[medoid_indices])
    score, k, labels, medoid_matrices = best  # type: ignore[misc]
    return labels, medoid_matrices, int(k), float(score)


def assign_graph_states(model: GraphStateModel, matrices: ConnectivitySeries | np.ndarray) -> np.ndarray:
    """Assign matrices to the nearest learned state without refitting."""
    if model.analysis_scope == "prospective" and not model.inductive_assignment_valid:
        raise ValueError("legacy spectral assignment has no validated inductive extension")
    if model.metric in GRAPH_SIMILARITY_METRICS:
        return assign_similarity_states(model, matrices)
    if model.feature_representation == "signed_lag_offdiag":
        feats = model.transform_features(matrices)
        if model.mixture is not None:
            return np.asarray(model.mixture.predict(feats), dtype=np.int64)
        if model.feature_centroids is None:
            raise ValueError("feature_centroids are required for graph-state assignment")
        return _assign_feature_labels(feats, model.feature_centroids)

    matrices = np.asarray(matrices, dtype=np.float64)
    if model.metric in FEATURE_METRICS or model.metric in KERNEL_METRICS:
        raw = _raw_features_for(
            matrices,
            model.metric,
            GraphStateConfig(
                metric=model.metric,
                eps=model.eps,
                gw_epsilon=model.gw_epsilon,
                gw_max_iter=model.gw_max_iter,
            ),
        )
        standardizer = _Standardizer(model.feature_mean, model.feature_scale)
        feats = standardizer.transform(raw)
        if model.feature_centroids is None:
            raise ValueError("feature_centroids are required for feature/kernel state assignment")
        return _assign_feature_labels(feats, model.feature_centroids)

    if model.metric in DISTANCE_METRICS:
        if model.medoid_matrices is None:
            raise ValueError("medoid_matrices are required for distance-based state assignment")
        dist = np.zeros((matrices.shape[0], model.medoid_matrices.shape[0]))
        for i, matrix in enumerate(matrices):
            for state, medoid in enumerate(model.medoid_matrices):
                dist[i, state] = pairwise_distances(
                    np.stack([matrix, medoid]),
                    model.metric,
                    eps=model.eps,
                    gw_epsilon=model.gw_epsilon,
                    gw_max_iter=model.gw_max_iter,
                )[0, 1]
        return np.argmin(dist, axis=1).astype(np.int64)

    raise ValueError(f"unknown metric '{model.metric}'")


def fit_graph_states(
    series: ConnectivitySeries,
    cfg: GraphStateConfig,
    *,
    fit_indices: np.ndarray | None = None,
    predictive_losses: dict[int, float] | None = None,
    feature_weights: np.ndarray | None = None,
) -> GraphStateModel:
    """Fit graph summaries and assign unseen windows with a frozen training transform.

    Optional nonnegative ``feature_weights`` are supplied by an external
    training-only reliability procedure. No graph uncertainty is inferred from
    the held-out windows here.
    """
    matrices = np.asarray(series.matrices, dtype=np.float64)
    n_windows = matrices.shape[0]
    train_idx = _validate_fit_indices(fit_indices, n_windows)
    train_matrices = matrices[train_idx]

    boundary_indices = boundary_indices_for_series(series, gap_factor=cfg.boundary_gap_factor)

    if cfg.metric in GRAPH_SIMILARITY_METRICS:
        return fit_similarity_states(
            series, cfg, train_idx, boundary_indices,
            predictive_losses=predictive_losses, feature_weights=feature_weights,
        )
    if cfg.feature_representation == "binary_lag_offdiag" or cfg.assignment == "kmedoids":
        raise ValueError("binary_lag_offdiag/kmedoids require an explicit support-similarity metric")

    feature_centroids = None
    feature_mean = None
    feature_scale = None
    medoid_matrices = None
    edge_indices = None
    lag_indices = None
    lag_count = None
    n_nodes = None
    pca_components = None
    pca_mean = None
    descriptive_centroids = None

    if cfg.feature_representation not in {"legacy", "signed_lag_offdiag"}:
        raise ValueError("feature_representation must be 'legacy' or 'signed_lag_offdiag'")
    if cfg.metric not in FEATURE_METRICS + KERNEL_METRICS + DISTANCE_METRICS:
        raise ValueError(f"unknown metric '{cfg.metric}'")
    if cfg.analysis_scope == "prospective" and cfg.feature_representation == "legacy":
        if cfg.metric in KERNEL_METRICS:
            raise ValueError("legacy spectral assignment has no validated inductive extension")
    if cfg.assignment == "gaussian_mixture" and cfg.feature_representation != "signed_lag_offdiag":
        raise ValueError("gaussian_mixture requires signed_lag_offdiag features")
    if feature_weights is not None and cfg.feature_representation != "signed_lag_offdiag":
        raise ValueError("feature_weights require signed_lag_offdiag features")

    if cfg.feature_representation == "signed_lag_offdiag":
        schema = graph_schema(series)
        raw, edge_indices, lag_indices, n_nodes, lag_count = _signed_lag_offdiag_features(series)
        train_raw = raw[train_idx]
        if cfg.n_states < 1:
            raise ValueError("n_states must be at least one")
        if cfg.select_k:
            candidate_ks = [k for k in (1, 2, 3, 4, 6) if k <= train_idx.size]
            if predictive_losses is None or any(
                k not in predictive_losses or not np.isfinite(predictive_losses[k]) for k in candidate_ks
            ):
                raise ValueError("select_k requires caller-owned inner predictive losses for every candidate")
            candidate_ks = [min(candidate_ks, key=lambda k: (predictive_losses[k], k))]
        else:
            candidate_ks = [cfg.n_states]
        if not candidate_ks or max(candidate_ks) > train_idx.size:
            raise ValueError("state count is infeasible for the training windows")
        train_features, standardizer = _fit_standardizer(train_raw, cfg.standardize)
        weights = None
        if feature_weights is not None:
            weights = np.asarray(feature_weights, dtype=np.float64)
            if (weights.shape != (raw.shape[1],) or not np.all(np.isfinite(weights))
                    or np.any(weights < 0) or not np.any(weights > 0)):
                raise ValueError("feature_weights must be finite nonnegative nonzero weights per feature")
            weights = weights.copy()
            train_features = train_features * np.sqrt(weights)
        train_features, pca_components, pca_mean = _apply_pca(
            train_features,
            pca_components=cfg.pca_components,
            seed=cfg.seed,
        )
        best = None
        for k in candidate_ks:
            mixture = None
            if cfg.assignment == "gaussian_mixture":
                if train_features.shape[0] < 2:
                    raise ValueError("gaussian_mixture needs at least two training observations")
                mixture = GaussianMixture(
                    n_components=k,
                    covariance_type="diag",
                    reg_covar=cfg.mixture_reg_covar,
                    n_init=cfg.mixture_n_init,
                    max_iter=cfg.mixture_max_iter,
                    random_state=cfg.seed,
                ).fit(train_features)
                if not mixture.converged_:
                    raise ValueError("gaussian_mixture did not converge; increase mixture_max_iter")
                train_labels = mixture.predict(train_features).astype(np.int64)
                centers = mixture.means_.astype(np.float64)
                score = (
                    float(silhouette_score(train_features, train_labels))
                    if 1 < len(np.unique(train_labels)) < train_features.shape[0]
                    else float("nan")
                )
            elif k == 1:
                train_labels = np.zeros(train_idx.size, dtype=np.int64)
                centers = train_features.mean(axis=0, keepdims=True)
                score = float("nan")
            else:
                km = KMeans(n_clusters=k, random_state=cfg.seed, n_init=10).fit(train_features)
                train_labels = km.labels_.astype(np.int64)
                centers = km.cluster_centers_.astype(np.float64)
                score = (
                    float(silhouette_score(train_features, train_labels))
                    if 1 < len(np.unique(train_labels)) < train_features.shape[0]
                    else float("nan")
                )
            if best is None or (
                not np.isnan(score) and (np.isnan(best[0]) or score > best[0])
            ):
                best = (score, k, train_labels, centers, mixture)
        silhouette, n_states, train_labels, feature_centroids, mixture = best  # type: ignore[misc]
        all_features = standardizer.transform(raw)
        if weights is not None:
            all_features = all_features * np.sqrt(weights)
        all_features = _transform_pca(all_features, components=pca_components, mean=pca_mean)
        memberships = (
            np.asarray(mixture.predict_proba(all_features), dtype=np.float64)
            if mixture is not None
            else np.eye(n_states, dtype=np.float64)[_assign_feature_labels(all_features, feature_centroids)]
        )
        labels = np.argmax(memberships, axis=1).astype(np.int64)
        labels[train_idx] = train_labels
        feature_mean, feature_scale = standardizer.mean, standardizer.scale
        centroids = _centroids(
            train_matrices,
            train_labels,
            n_states,
            "frobenius",
            cfg.eps,
        )
        descriptive_centroids = (
            _centroids(matrices, labels, n_states, "frobenius", cfg.eps)
            if cfg.analysis_scope == "descriptive" else None
        )
        logger.info(
            "Fit %d signed lag-offdiag states (fit_windows=%d/%d)",
            n_states,
            len(train_idx),
            n_windows,
        )
        return GraphStateModel(
            labels=labels.astype(np.int64),
            centroids=centroids,
            n_states=int(n_states),
            silhouette=float(silhouette),
            metric="frobenius",
            window_starts=np.asarray(series.window_starts, dtype=int),
            feature_centroids=np.asarray(feature_centroids, dtype=np.float64),
            feature_mean=None if feature_mean is None else np.asarray(feature_mean, dtype=np.float64),
            feature_scale=None if feature_scale is None else np.asarray(feature_scale, dtype=np.float64),
            fit_indices=train_idx,
            boundary_indices=boundary_indices,
            feature_representation=cfg.feature_representation,
            assignment="gaussian_mixture" if mixture is not None else "kmeans",
            mixture=mixture,
            membership_probabilities=memberships,
            feature_weights=weights,
            effective_algorithm="gaussian_mixture_diag" if mixture is not None else "kmeans",
            effective_distance=(
                "diagonal_gaussian_negative_log_density" if mixture is not None
                else "squared_euclidean_in_fitted_feature_space"
            ),
            requested_metric=cfg.metric,
            analysis_scope=cfg.analysis_scope,
            edge_indices=edge_indices,
            lag_indices=lag_indices,
            lag_count=lag_count,
            n_nodes=n_nodes,
            pca_components=pca_components,
            pca_mean=pca_mean,
            descriptive_centroids=descriptive_centroids,
            lag_centroids=np.stack(
                [
                    np.asarray(series.lagged_matrices)[train_idx][
                        train_labels == state
                    ].mean(axis=0)
                    if series.lagged_matrices is not None and np.any(train_labels == state)
                    else np.zeros((lag_count, n_nodes, n_nodes))
                    for state in range(n_states)
                ]
            ),
            graph_schema=schema,
            selection_loss=None if predictive_losses is None else predictive_losses[int(n_states)],
            eps=cfg.eps,
            gw_epsilon=cfg.gw_epsilon,
            gw_max_iter=cfg.gw_max_iter,
        )

    if cfg.metric in FEATURE_METRICS:
        train_labels, feature_centroids, standardizer, n_states, silhouette = _fit_feature_path(
            train_matrices, cfg
        )
        all_feats = standardizer.transform(_raw_features_for(matrices, cfg.metric, cfg))
        labels = _assign_feature_labels(all_feats, feature_centroids)
        labels[train_idx] = train_labels
        feature_mean, feature_scale = standardizer.mean, standardizer.scale
    elif cfg.metric in KERNEL_METRICS:
        train_labels, feature_centroids, standardizer, n_states, silhouette = _fit_kernel_path(
            train_matrices, cfg
        )
        all_feats = standardizer.transform(_raw_features_for(matrices, cfg.metric, cfg))
        labels = _assign_feature_labels(all_feats, feature_centroids)
        labels[train_idx] = train_labels
        feature_mean, feature_scale = standardizer.mean, standardizer.scale
    elif cfg.metric in DISTANCE_METRICS:
        train_labels, medoid_matrices, n_states, silhouette = _fit_distance_path(train_matrices, cfg)
        temp_model = GraphStateModel(
            labels=train_labels,
            centroids=medoid_matrices,
            n_states=n_states,
            silhouette=silhouette,
            metric=cfg.metric,
            window_starts=series.window_starts[train_idx],
            medoid_matrices=medoid_matrices,
            eps=cfg.eps,
            gw_epsilon=cfg.gw_epsilon,
            gw_max_iter=cfg.gw_max_iter,
        )
        labels = assign_graph_states(temp_model, matrices)
        labels[train_idx] = train_labels
    else:
        raise ValueError(
            f"unknown metric '{cfg.metric}'; choices: {FEATURE_METRICS + KERNEL_METRICS + DISTANCE_METRICS}"
        )

    centroids = _centroids(
        train_matrices, train_labels, n_states, cfg.metric, cfg.eps, medoid_matrices=medoid_matrices
    )
    descriptive_centroids = (
        _centroids(matrices, labels, n_states, cfg.metric, cfg.eps)
        if cfg.analysis_scope == "descriptive" else None
    )
    logger.info(
        "Fit %d dataset-global connectivity states (metric=%s, silhouette=%.3f, fit_windows=%d/%d)",
        n_states,
        cfg.metric,
        silhouette,
        len(train_idx),
        n_windows,
    )
    return GraphStateModel(
        labels=labels.astype(np.int64),
        centroids=centroids,
        n_states=n_states,
        silhouette=float(silhouette),
        metric=cfg.metric,
        window_starts=np.asarray(series.window_starts, dtype=int),
        feature_centroids=(
            None if feature_centroids is None else np.asarray(feature_centroids, dtype=np.float64)
        ),
        feature_mean=None if feature_mean is None else np.asarray(feature_mean, dtype=np.float64),
        feature_scale=None if feature_scale is None else np.asarray(feature_scale, dtype=np.float64),
        medoid_matrices=None if medoid_matrices is None else np.asarray(medoid_matrices, dtype=np.float64),
        fit_indices=train_idx,
        boundary_indices=boundary_indices,
        membership_probabilities=np.eye(n_states, dtype=np.float64)[labels],
        descriptive_centroids=descriptive_centroids,
        effective_algorithm=(
            "spectral_legacy_original_feature_assignment_proxy" if cfg.metric in KERNEL_METRICS
            else "kmedoids_alternating" if cfg.metric in DISTANCE_METRICS else "kmeans"
        ),
        effective_distance=(
            "rbf_on_duplicated_signed_graph_features" if cfg.metric in KERNEL_METRICS else cfg.metric
        ),
        requested_metric=cfg.metric,
        analysis_scope=cfg.analysis_scope,
        inductive_assignment_valid=cfg.metric not in KERNEL_METRICS,
        eps=cfg.eps,
        gw_epsilon=cfg.gw_epsilon,
        gw_max_iter=cfg.gw_max_iter,
    )
